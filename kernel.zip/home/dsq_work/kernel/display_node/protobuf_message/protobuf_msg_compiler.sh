protoc -I=. --cpp_out=. display_msg.proto 
