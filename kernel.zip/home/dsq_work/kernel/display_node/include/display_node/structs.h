#include "json.hpp"

using json = nlohmann::json;
using namespace std;

namespace aviz
{
    struct Point3d
    {
        double x;
        double y;
        double z;
    };

    void from_json(const json &j, Point3d &p)
    {
        j.at("x").get_to(p.x);
        j.at("y").get_to(p.y);
        if (j.contains("z"))
        {
            j.at("z").get_to(p.z);
        }
    }

    struct EulerAngle
    {
        // 俯仰角
        double pitch;
        // 航向角
        double yaw;
        // 滚转角
        double roll;
    };

    void from_json(const json &j, EulerAngle &e)
    {
        j.at("yaw").get_to(e.yaw);
        if (j.contains("pitch"))
        {
            j.at("pitch").get_to(e.pitch);
        }
        if (j.contains("roll"))
        {
            j.at("roll").get_to(e.roll);
        }
    }

    struct Curve
    {
        double c0;
        double c1;
        double c2;
        double c3;
    };

    void from_json(const json &j, Curve &c)
    {
        j.at("c0").get_to(c.c0);
        j.at("c1").get_to(c.c1);
        j.at("c2").get_to(c.c2);
        j.at("c3").get_to(c.c3);
    }

    struct Lane
    {
        Point3d start_point;
        Point3d end_point;
        Curve curve;
        vector<int8_t> types;
        int8_t nums;
    };

    void from_json(const json &j, Lane &lane)
    {
        j.at("start_point").get_to(lane.start_point);
        j.at("end_point").get_to(lane.end_point);
        j.at("curve").get_to(lane.curve);
        j.at("nums").get_to(lane.nums);
        j.at("types").get_to(lane.types);
    }

    struct Objective
    {
        Point3d location;
        EulerAngle euler_angle;
        double speed;
        Point3d size;
        int32_t type;
        int32_t track_id;
        float ttc;
        int32_t serial_number;
    };

    void from_json(const json &j, Objective &obj)
    {
        j.at("location").get_to(obj.location);
        j.at("euler_angle").get_to(obj.euler_angle);
        j.at("size").get_to(obj.size);
        j.at("type").get_to(obj.type);
        j.at("speed").get_to(obj.speed);
        if (j.contains("track_id"))
        {
            j.at("track_id").get_to(obj.track_id);
        }
        if (j.contains("serial_number"))
        {
            j.at("serial_number").get_to(obj.serial_number);
        }
        if (j.contains("ttc"))
        {
            j.at("ttc").get_to(obj.ttc);
        }
    }

    struct Ego
    {
        Point3d location;
        EulerAngle euler_angle;
        double speed;
        Point3d size;
    };

    void from_json(const json &j, Ego &ego)
    {
        j.at("location").get_to(ego.location);
        j.at("euler_angle").get_to(ego.euler_angle);
        j.at("size").get_to(ego.size);
        j.at("speed").get_to(ego.speed);
    }
    struct PublishMessage
    {
        bool on;
        Ego ego;
        vector<Objective> objs;
        Lane lane;
    };

    void from_json(const json &j, PublishMessage &p)
    {
        j.at("on").get_to(p.on);
        j.at("ego").get_to(p.ego);
        j.at("objs").get_to(p.objs);
        j.at("lane").get_to(p.lane);
    }
}