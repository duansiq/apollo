#pragma once // 防止头文件被重复包含

#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <cstring>
#include <iostream>
#include <fstream>
#include <thread>
#include <google/protobuf/descriptor.h>
#include <opencv2/opencv.hpp>

#include "rclcpp/rclcpp.hpp"
#include "visualization_msgs/msg/marker.hpp"
#include "visualization_msgs/msg/marker_array.hpp"
#include "geometry_msgs/msg/point.h"
#include <tf2/LinearMath/Quaternion.h>
#include "tf2_msgs/msg/tf_message.hpp"
#include "display_node/display_msg.pb.h"
#include "geometry_msgs/msg/point.hpp"
#include "geometry_msgs/msg/polygon_stamped.hpp"
#include <geometry_msgs/msg/pose.hpp>
#include <sensor_msgs/msg/image.hpp>
#include "SFML/Audio.hpp"
#include "structs.h"
#include <ament_index_cpp/get_package_share_directory.hpp>

using namespace std;
using google::protobuf::EnumDescriptor;
using google::protobuf::EnumValueDescriptor;

#define PORT 8888
#define QUEUE 10
// #define IP "192.168.2.106"
#define IP "127.0.0.1"

#define FRAME_ID "/base_link"
#define EGO_FRAME_ID "/ego_link"
#define DISPLAY_LANE "display_lane"
#define DISPLAY_OBJ_VISION "display_obj_vision"
#define DISPLAY_OBJ_FUSION "display_obj_fusion"
#define DISPLAY_OBJ_MODEL "display_obj_model"
#define DISPLAY_RADAR "display_radar"
#define DISPLAY_PREDICTION "display_prediction"
#define DISPLAY_PLANNING "display_planning"
#define DISPLAY_REJECT "display_reject"
#define DISPLAY_TFSIGN "display_tfsign"
#define DISPLAY_EGO_CAR "display_ego_car"
#define DISPLAY_STATE_MACHINE "display_state_machine"
#define DISPLAY_TF "tf"
#define DISPLAY_TRAFFIC_LIGHT "display_traffic_light"
#define QUEUE_MAX_SIZE 15

class DisplayNode : public rclcpp::Node
{

private:
    void timer_callback();
    void clear_timer_callback();
    void voice_broadcast_timer_callback();
    void pub_lanes(google::protobuf::RepeatedPtrField<display_aviz::LaneLine> lanes);
    void pub_obstacle(google::protobuf::RepeatedPtrField<display_aviz::Obstacle> obstacles,
                      const char *pub_ob_type);
    void pub_tf_sign(google::protobuf::RepeatedPtrField<display_aviz::TrafficSign> traffic_signs);
    void pub_ego_car();
    void pub_ego_car(string resource_path);
    void init_load_images();
    visualization_msgs::msg::Marker text_marker(display_aviz::Obstacle position);
    visualization_msgs::msg::Marker text_marker_radar(display_aviz::RadarObject radar_object);
    visualization_msgs::msg::Marker text_marker_planning(display_aviz::Trajectory trajectory);
    visualization_msgs::msg::Marker text_marker_information(display_aviz::Obstacle obstacle);
    visualization_msgs::msg::Marker text_marker_sm(float position_x, float position_y, float position_z, std::string text);
    void pub_predictions(display_aviz::Prediction prediction);
    void pub_polygon(display_aviz::Prediction prediction);
    void pub_planning(display_aviz::Trajectory trajectory);
    void pub_planning(vector<aviz::Point3d> &points);
    void pub_radar(google::protobuf::RepeatedPtrField<display_aviz::RadarObject> radarObjects);
    void pub_state_machine(display_aviz::StateMachine state_machine);
    void generate_points(visualization_msgs::msg::Marker &marker,
                         display_aviz::FloatVector3 start_point,
                         display_aviz::FloatVector3 end_point,
                         display_aviz::Curve curve);
    std::string message_to_string(const std::vector<uint8_t> &message);
    cv::Mat find_signs_template(display_aviz::TrafficSign &traffic_sign);
    void play_audio(std::string audioPath);
    void push_voice(int &pre_state, int state, string voice_name);
    int create_server();
    void parser_message();
    void pub_tf(double x, double y, double z);
    void pub_traffic_light();
    void set_main_dir();
    void set_planning_points(vector<aviz::Point3d> &points);

private:
    // 声明发布者
    rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr pub_tf_sign_;
    google::protobuf::RepeatedPtrField<display_aviz::TrafficSign> traffic_signs_;
    rclcpp::Publisher<geometry_msgs::msg::PolygonStamped>::SharedPtr pub_reject_;
    rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr pub_ego_car_;
    rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr pub_state_machine_;
    rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr pub_traffic_light_;
    rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr pub_lane_, pub_ob_vision_, pub_ob_fusion_, pub_ob_model_, pub_radar_, pub_prediction_, pub_planning_;
    rclcpp::Publisher<tf2_msgs::msg::TFMessage>::SharedPtr pub_tf_;
    rclcpp::TimerBase::SharedPtr timer_;
    rclcpp::TimerBase::SharedPtr clear_timer_;
    rclcpp::TimerBase::SharedPtr voice_broadcast_timer_;
    rclcpp::CallbackGroup::SharedPtr voice_timer_group_;
    rclcpp::CallbackGroup::SharedPtr timer_group_;

    std::shared_ptr<display_aviz::PublishMessage> pub_ptr;
    aviz::PublishMessage msg;

    // traffic sign images
    cv::Mat template_sign_background_;
    cv::Mat template_sign_cancel_;
    cv::Mat template_sign_high_speed_;
    cv::Mat template_sign_low_speed;
    cv::Mat template_sign_high_limit_;
    cv::Mat template_sign_non_motorized_;
    cv::Mat template_sign_no_parking_;
    cv::Mat template_sign_no_template_;
    cv::Mat template_sign_no_u_turn_;
    cv::Mat template_sign_slow_;
    cv::Mat template_sign_stop_;
    cv::Mat template_sign_vehicle_;
    cv::Mat template_sign_weight_limit_;
    cv::Mat template_sign_width_limit_;

    queue<cv::Mat> MatQueue;
    int seq_ = 0;
    int pre_acc_state = 0;
    int pre_icc_state = 0;
    int pre_hwa_state = 0;
    queue<string> voice_broadcast_queue;
    size_t id;
    bool clear_flag_ = true;
    bool q_pop_flag_ = false;
    size_t pop_time_cnt_ = 0;
    bool is_simulation = 0;
    string main_dir;
    vector<aviz::Point3d> points;
    // 车道线显示的颜色：未知，红色，橙色，黄色，绿色，蓝色，白色;
    float line_colors[7][3] = {{0.0, 0.0, 0.0}, {1.0, 0.0, 0.0}, {1.0, 0.38, 0}, {1.0, 1.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 0.0, 1.0}, {0.0, 1.0, 1.0}};
    // 目标框显示的颜色：浅灰色、灰色、暗淡的灰色
    float box_colors[3][3] = {{0.83, 0.83, 0.83}, {1.0, 1.0, 1.0}, {0.0, 1.0, 0.0}};
    // 目标框显示的颜色：
    float box_model_colors[11][3] = {{1.0, 0.0, 0.0}, {1.0, 1.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 1.0, 0.0}, {1.0, 1.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 1.0, 0.0}};
    string obj_names[12] = {"UNKNOW", "CAR", "BUS", "PED", "BICYCLE", "TRUCK", "MOTO", "RIDER", "SIGN", "LIGHT", "CONE", "OTHERS"};

public:
    DisplayNode(std::string name);
    ~DisplayNode();

public:
    int server;
};
