/******************************************************************************************
 * @FilePath: display_node.cpp
 * @Author: Name XXX
 * @Date: 2023-08-04 16:23:28
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2023-08-04 17:44:02
 * @Copyright: 2023 AICC Inc. All Rights Reserved.
 * @Input: 
 * @Output: 
 * @Descripttion: 
*****************************************************************************************/
#include "display_node/display_node.h"

/******************************************************************************************
 * @brief: 
 * @return 
*****************************************************************************************/
void DisplayNode::timer_callback()
{
    if (is_simulation)
    {
        if (points.size() > 0)
        {
            // 规划
            pub_planning(points);
        }
    }
    else
    {
        char buffer[1024 * 1000];
        memset(buffer, 0, sizeof(buffer));
        pub_ptr = std::make_shared<display_aviz::PublishMessage>();
        int len = recv(server, buffer, sizeof(buffer), 0);
        // RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "====================recv====================");
        pub_ptr->ParseFromArray(buffer, len);
        // 规划
        pub_planning(pub_ptr->planning_msg());
    }
    pub_traffic_light();
    // google::protobuf::ShutdownProtobufLibrary();
    id = 0;
    std::shared_ptr<vector<vector<float>>> bboxes_ptr = std::make_shared<vector<vector<float>>>();
    pub_lanes(pub_ptr->road_msg());
    // 图像：目标检测
    pub_obstacle(pub_ptr->obstacles_vision_msg(), DISPLAY_OBJ_VISION);
    // 图像+雷达融合：目标检测
    pub_obstacle(pub_ptr->obstacles_fusion_msg(), DISPLAY_OBJ_FUSION);
    // 建模：目标检测
    pub_obstacle(pub_ptr->obstacles_model_msg(), DISPLAY_OBJ_MODEL);
    // 雷达
    pub_radar(pub_ptr->objects_radar_msg());
    // 预测
    pub_predictions(pub_ptr->prediction_msg());
    pub_polygon(pub_ptr->prediction_msg());

    // state machine
    pub_state_machine(pub_ptr->state_machine_msg());
    // traffic sign
    this->traffic_signs_ = pub_ptr->traffic_signs_msg();
}

void DisplayNode::clear_timer_callback()
{
    // pop_time_cnt_ ++;
    // if(pop_time_cnt_ == 10)
    // {
    //     q_pop_flag_ = !q_pop_flag_;
    //     pop_time_cnt_ = 0;
    // }

    // pub ego car
    if (is_simulation)
    {

        pub_ego_car("/meshes/FORD_GT/model.dae");
    }
    else
    {
        pub_ego_car();
    }
    // pub_traffic_signs
    pub_tf_sign(this->traffic_signs_);
    // RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "# %d Server startup, running...", seq_);
    seq_++;
    if (seq_ > 2147483646)
    {
        seq_ = 0;
    }
}

void DisplayNode::voice_broadcast_timer_callback()
{
    // 迭代访问队列中的所有元素
    while (!voice_broadcast_queue.empty())
    {
        string audioPath = main_dir + "/audio/" + voice_broadcast_queue.front() + ".wav";
        play_audio(audioPath);
        voice_broadcast_queue.pop();
    }
}

void DisplayNode::play_audio(std::string audioPath)
{
    sf::SoundBuffer audioBuffer;
    if (!audioBuffer.loadFromFile(audioPath))
    {
        RCLCPP_ERROR_ONCE(rclcpp::get_logger("rclcpp"), "====ERROR: Unable to load audio file.====");
        return;
    }

    sf::Sound sound;
    sound.setBuffer(audioBuffer);
    sound.play();
    while (sound.getStatus() == sf::Sound::Playing)
    {
        // 等待音频播放完成
    }
}

void DisplayNode::init_load_images()
{
    template_sign_background_ = cv::imread(main_dir + "/images/background.png", cv::IMREAD_COLOR);
    template_sign_cancel_ = cv::imread(main_dir + "/images/cancel.png", cv::IMREAD_COLOR);
    template_sign_high_limit_ = cv::imread(main_dir + "/images/high_limit.png", cv::IMREAD_COLOR);
    template_sign_high_speed_ = cv::imread(main_dir + "/images/high_speed.png", cv::IMREAD_COLOR);
    template_sign_low_speed = cv::imread(main_dir + "/images/low_speed.png", cv::IMREAD_COLOR);
    template_sign_non_motorized_ = cv::imread(main_dir + "/images/non_motorized.png", cv::IMREAD_COLOR);
    template_sign_no_parking_ = cv::imread(main_dir + "/images/no_pass.png", cv::IMREAD_COLOR);
    template_sign_no_template_ = cv::imread(main_dir + "/images/no_template.png", cv::IMREAD_COLOR);
    template_sign_no_u_turn_ = cv::imread(main_dir + "/images/no_u_turn.png", cv::IMREAD_COLOR);
    template_sign_slow_ = cv::imread(main_dir + "/images/slow.png", cv::IMREAD_COLOR);
    template_sign_stop_ = cv::imread(main_dir + "/images/stop.png", cv::IMREAD_COLOR);
    template_sign_vehicle_ = cv::imread(main_dir + "/images/vehicle.png", cv::IMREAD_COLOR);
    template_sign_weight_limit_ = cv::imread(main_dir + "/images/weight_limit.png", cv::IMREAD_COLOR);
    template_sign_width_limit_ = cv::imread(main_dir + "/images/width_limit.png", cv::IMREAD_COLOR);
}
void DisplayNode::pub_tf_sign(google::protobuf::RepeatedPtrField<display_aviz::TrafficSign> traffic_signs)
{
    // //每个标志延迟3s清空显示队列
    // if(!MatQueue.empty() && q_pop_flag_)
    // {
    //     MatQueue.pop();
    // }
    // else if(MatQueue.empty())
    // {
    //     pop_time_cnt_ = 0;
    // }

    // cv::Mat background = this->template_sign_background_.clone();
    // //add traffic sign
    // for (display_aviz::TrafficSign traffic_sign : traffic_signs)
    // {

    //     MatQueue.push(find_signs_template(traffic_sign));

    //     // 如果队列已满，从头部出队列
    //     if (MatQueue.size() > QUEUE_MAX_SIZE)
    //     {
    //         MatQueue.pop();
    //     }
    // }

    // std::queue<cv::Mat> MatQueueCopy = MatQueue;
    // cv::Point focus;
    // focus.y = 60;
    // int i = 0;
    // while (!MatQueueCopy.empty())
    // {
    //     cv::Mat mat = MatQueueCopy.front();
    //     cv::Mat roi_image = background(cv::Rect(focus.x,focus.y,mat.cols,mat.rows));
    //     mat.copyTo(roi_image);

    //     if(i%5 == 0)
    //     {
    //         focus.y += int(i/5*(mat.rows + 15));
    //         focus.x = 60;
    //     }
    //     focus.x += int(i%5 * (mat.cols + 20));
    //     i++;

    //     MatQueueCopy.pop();
    // }
    cv::Point focus;
    focus.y = 20;

    int i = 0;
    cv::Mat background = this->template_sign_background_.clone();
    // add traffic sign
    for (display_aviz::TrafficSign traffic_sign : traffic_signs)
    {
        if (i % 5 == 0)
        {
            focus.y += int(i / 5 * (template_sign_high_speed_.rows + 20));
            focus.x = 60;
        }
        focus.x = 0;
        focus.x += int(i % 5 * (template_sign_high_speed_.cols + 20));

        cv::Mat sign = find_signs_template(traffic_sign);
        cv::Mat roi_image = background(cv::Rect(focus.x, focus.y, sign.cols, sign.rows));
        sign.copyTo(roi_image);
        i++;
        if (i > 14)
        {
            break;
        }
    }
    // 创建 ROS2 消息类型的图像
    auto msg = std::make_shared<sensor_msgs::msg::Image>();
    // 设置图像的宽度、高度、颜色编码、像素数据和步长
    msg->width = background.cols;
    msg->height = background.rows;
    msg->encoding = "bgr8";
    msg->data.resize(background.total() * background.elemSize());
    std::memcpy(msg->data.data(), background.data, msg->data.size());
    msg->step = background.step;
    pub_tf_sign_->publish(*msg);
}
cv::Mat DisplayNode::find_signs_template(display_aviz::TrafficSign &traffic_sign)
{
    float value = traffic_sign.value();
    if (traffic_sign.class_type() == display_aviz::ENUM_TRAFFIC_SIGN_TYPE::TRAFFIC_SIGN_TYPE_LIMIT_HIGH_SPEED)
    {
        cv::Mat high_speed = this->template_sign_high_speed_.clone();
        cv::putText(high_speed, std::to_string((int)value), cv::Point(15, 38), cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(0, 0, 0), 3);
        return high_speed;
    }
    else if (traffic_sign.class_type() == display_aviz::ENUM_TRAFFIC_SIGN_TYPE::TRAFFIC_SIGN_TYPE_LIMIT_LOW_SPEED)
    {
        cv::Mat low_speed = this->template_sign_low_speed.clone();
        cv::putText(low_speed, std::to_string((int)value), cv::Point(15, 38), cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(0, 0, 0), 3);
        return low_speed;
    }
    else if (traffic_sign.class_type() == display_aviz::ENUM_TRAFFIC_SIGN_TYPE::TRAFFIC_SIGN_TYPE_LIMIT_SPEED_CANCEL)
    {
        cv::Mat sign_cancel = this->template_sign_cancel_.clone();
        cv::putText(sign_cancel, std::to_string((int)value), cv::Point(15, 38), cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(0, 0, 0), 1);
        return sign_cancel;
    }
    else if (traffic_sign.class_type() == display_aviz::ENUM_TRAFFIC_SIGN_TYPE::TRAFFIC_SIGN_TYPE_LIMIT_HEIGHT)
    {
        cv::Mat high_limit = this->template_sign_high_limit_.clone();
        cv::putText(high_limit, std::to_string((int)value), cv::Point(15, 38), cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(0, 0, 0), 1);
        return high_limit;
    }
    else if (traffic_sign.class_type() == display_aviz::ENUM_TRAFFIC_SIGN_TYPE::TRAFFIC_SIGN_TYPE_LIMIT_WEIGHT)
    {
        cv::Mat weight_limit = this->template_sign_weight_limit_.clone();
        cv::putText(weight_limit, std::to_string((int)value), cv::Point(15, 38), cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(0, 0, 0), 1);
        return weight_limit;
    }
    else if (traffic_sign.class_type() == display_aviz::ENUM_TRAFFIC_SIGN_TYPE::TRAFFIC_SIGN_TYPE_LIMIT_WIDTH)
    {
        cv::Mat width_limit = this->template_sign_width_limit_.clone();
        cv::putText(width_limit, std::to_string((int)value), cv::Point(15, 38), cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(0, 0, 0), 1);
        return width_limit;
    }
    else if (traffic_sign.class_type() == display_aviz::ENUM_TRAFFIC_SIGN_TYPE::TRAFFIC_SIGN_TYPE_NO_U_TURN)
    {
        cv::Mat no_u_turn = this->template_sign_no_u_turn_.clone();
        return no_u_turn;
    }
    else if (traffic_sign.class_type() == display_aviz::ENUM_TRAFFIC_SIGN_TYPE::TRAFFIC_SIGN_TYPE_I_MOTORS || traffic_sign.class_type() == display_aviz::ENUM_TRAFFIC_SIGN_TYPE::TRAFFIC_SIGN_TYPE_I_MOTORSLANE)
    {
        cv::Mat vehicle = this->template_sign_vehicle_.clone();
        return vehicle;
    }
    else if (traffic_sign.class_type() == display_aviz::ENUM_TRAFFIC_SIGN_TYPE::TRAFFIC_SIGN_TYPE_I_NONMOTORS || traffic_sign.class_type() == display_aviz::ENUM_TRAFFIC_SIGN_TYPE::TRAFFIC_SIGN_TYPE_I_NONMOTORSLANE)
    {
        cv::Mat non_motorized = this->template_sign_non_motorized_.clone();
        return non_motorized;
    }
    else if (traffic_sign.class_type() == display_aviz::ENUM_TRAFFIC_SIGN_TYPE::TRAFFIC_SIGN_TYPE_P_SLOWFOR)
    {
        cv::Mat slow = this->template_sign_slow_.clone();
        return slow;
    }
    else if (traffic_sign.class_type() == display_aviz::ENUM_TRAFFIC_SIGN_TYPE::TRAFFIC_SIGN_TYPE_P_STOPFOR)
    {
        cv::Mat stop = this->template_sign_stop_.clone();
        return stop;
    }
    else if (traffic_sign.class_type() == display_aviz::ENUM_TRAFFIC_SIGN_TYPE::TRAFFIC_SIGN_TYPE_P_NOPARKING)
    {
        cv::Mat no_parking = this->template_sign_no_parking_.clone();
        return no_parking;
    }
    else
    {
        cv::Mat no_template = this->template_sign_no_template_.clone();
        return no_template;
    }
}

std::string DisplayNode::message_to_string(const std::vector<uint8_t> &message)
{
    std::stringstream ss;
    for (const auto &byte : message)
    {
        ss << byte;
    }
    return ss.str();
}

void DisplayNode::push_voice(int &pre_state, int state, string voice_name)
{
    if (pre_state != state)
    {
        voice_broadcast_queue.push(voice_name);
        pre_state = state;
    }
}
void DisplayNode::pub_state_machine(display_aviz::StateMachine state_machine)
{
    visualization_msgs::msg::MarkerArray mArr;
    visualization_msgs::msg::Marker marker_delet;
    marker_delet.action = visualization_msgs::msg::Marker::DELETEALL;
    marker_delet.type = visualization_msgs::msg::Marker::CUBE;
    mArr.markers.push_back(marker_delet);

    // ACC
    {
        visualization_msgs::msg::Marker marker;
        marker.header.frame_id = FRAME_ID;
        marker.header.stamp = this->get_clock()->now();
        marker.id = ++id;
        marker.type = visualization_msgs::msg::Marker::CUBE;
        marker.action = visualization_msgs::msg::Marker::ADD;
        marker.pose.position.x = 10;
        marker.pose.position.y = 20;
        marker.pose.position.z = 0;

        marker.scale.x = 3;
        marker.scale.y = 3;
        marker.scale.z = 1;
        // std::cout << "acc : " << state_machine.acc_mode() << std::endl;
        if (state_machine.acc_mode() == 1 || state_machine.acc_mode() == 2)
        {
            marker.color.a = 1.0;
            marker.color.r = 1.0;
            marker.color.g = 1.0;
            marker.color.b = 0.0;
            push_voice(pre_acc_state, 1, "acc_ready");
        }
        else if (state_machine.acc_mode() == 3 || state_machine.acc_mode() == 4 || state_machine.acc_mode() == 5 || state_machine.acc_mode() == 6)
        {
            marker.color.a = 1.0;
            marker.color.r = 0.0;
            marker.color.g = 1.0;
            marker.color.b = 0.0;
            push_voice(pre_acc_state, 2, "acc_activated");
        }
        else
        {
            marker.color.a = 1.0;
            marker.color.r = 0.83;
            marker.color.g = 0.83;
            marker.color.b = 0.83;
            push_voice(pre_acc_state, 0, "acc_exited");
        }
        mArr.markers.push_back(marker);
        mArr.markers.push_back(text_marker_sm(10, 25, 1, "ACC"));
    }

    // ICC
    {
        visualization_msgs::msg::Marker marker;
        marker.header.frame_id = FRAME_ID;
        marker.header.stamp = this->get_clock()->now();
        marker.id = ++id;
        marker.type = visualization_msgs::msg::Marker::CUBE;
        marker.action = visualization_msgs::msg::Marker::ADD;
        marker.pose.position.x = 20;
        marker.pose.position.y = 20;
        marker.pose.position.z = 0;

        marker.scale.x = 3;
        marker.scale.y = 3;
        marker.scale.z = 1;

        // std::cout << "icc : " << state_machine.icc_state() << std::endl;
        if (state_machine.icc_state() == 1)
        {
            marker.color.a = 1.0;
            marker.color.r = 1.0;
            marker.color.g = 1.0;
            marker.color.b = 0.0;
            push_voice(pre_icc_state, 1, "icc_ready");
        }
        else if (state_machine.icc_state() == 2 || state_machine.icc_state() == 3)
        {
            marker.color.a = 1.0;
            marker.color.r = 0.0;
            marker.color.g = 1.0;
            marker.color.b = 0.0;
            push_voice(pre_icc_state, 2, "icc_activated");
        }
        else
        {
            marker.color.a = 1.0;
            marker.color.r = 0.83;
            marker.color.g = 0.83;
            marker.color.b = 0.83;
            push_voice(pre_icc_state, 0, "icc_exited");
        }
        mArr.markers.push_back(marker);
        mArr.markers.push_back(text_marker_sm(20, 25, 1, "ICC"));
    }

    // HWA
    {
        visualization_msgs::msg::Marker marker;
        marker.header.frame_id = FRAME_ID;
        marker.header.stamp = this->get_clock()->now();
        marker.id = ++id;
        marker.type = visualization_msgs::msg::Marker::CUBE;
        marker.action = visualization_msgs::msg::Marker::ADD;
        marker.pose.position.x = 30;
        marker.pose.position.y = 20;
        marker.pose.position.z = 0;

        marker.scale.x = 3;
        marker.scale.y = 3;
        marker.scale.z = 1;
        // std::cout << "alc : " << state_machine.alc_state() << std::endl;
        if (state_machine.alc_state() == 1 || state_machine.alc_state() == 2)
        {
            marker.color.a = 1.0;
            marker.color.r = 1.0;
            marker.color.g = 1.0;
            marker.color.b = 0.0;
            push_voice(pre_hwa_state, 1, "hwa_ready");
        }
        else if (state_machine.alc_state() > 2 && state_machine.alc_state() < 11)
        {
            marker.color.a = 1.0;
            marker.color.r = 0.0;
            marker.color.g = 1.0;
            marker.color.b = 0.0;

            if (state_machine.alc_state() == 3)
            {
                mArr.markers.push_back(text_marker_sm(35, 25, 1, "Request Left & Reject"));
                push_voice(pre_hwa_state, 3, "turn_left_request_reject");
            }
            if (state_machine.alc_state() == 4)
            {
                mArr.markers.push_back(text_marker_sm(35, 25, 1, "Changeing Left"));
                push_voice(pre_hwa_state, 4, "turning_left");
            }
            if (state_machine.alc_state() == 5)
            {
                mArr.markers.push_back(text_marker_sm(35, 25, 1, "Finish Left"));
                push_voice(pre_hwa_state, 5, "left_turn_finish");
            }
            if (state_machine.alc_state() == 6)
            {
                mArr.markers.push_back(text_marker_sm(35, 25, 1, "Left Break & Take Over"));
                push_voice(pre_hwa_state, 6, "left_break_take_over");
            }

            if (state_machine.alc_state() == 7)
            {
                mArr.markers.push_back(text_marker_sm(35, 25, 1, "Request Right & Reject"));
                push_voice(pre_hwa_state, 7, "turn_right_request_reject");
            }
            if (state_machine.alc_state() == 8)
            {
                mArr.markers.push_back(text_marker_sm(35, 25, 1, "Changeing Right"));
                push_voice(pre_hwa_state, 8, "turning_right");
            }
            if (state_machine.alc_state() == 9)
            {
                mArr.markers.push_back(text_marker_sm(35, 25, 1, "Finish Right"));
                push_voice(pre_hwa_state, 9, "right_turn_finish");
            }
            if (state_machine.alc_state() == 10)
            {
                mArr.markers.push_back(text_marker_sm(35, 25, 1, "Right Break & Take Over"));
                push_voice(pre_hwa_state, 10, "right_break_take_over");
            }
        }
        else
        {
            marker.color.a = 1.0;
            marker.color.r = 0.83;
            marker.color.g = 0.83;
            marker.color.b = 0.83;
            push_voice(pre_hwa_state, 0, "hwa_exited");
        }
        mArr.markers.push_back(marker);
        mArr.markers.push_back(text_marker_sm(30, 25, 1, "ALC/HWA"));
    }

    pub_state_machine_->publish(mArr);
}

void DisplayNode::pub_polygon(display_aviz::Prediction prediction)
{
    auto polygon = geometry_msgs::msg::PolygonStamped();
    polygon.header.frame_id = FRAME_ID;

    if (prediction.reject_status() & 1)
    {
        auto polygon = geometry_msgs::msg::PolygonStamped();
        polygon.header.frame_id = FRAME_ID;
        polygon.polygon.points.clear();
        pub_reject_->publish(polygon);
    }
    else
    {
        // left front reject
        if (prediction.reject_status() & 8)
        {
            geometry_msgs::msg::Point32 point;
            point.x = 20;
            point.y = 1.875;
            point.z = 0;
            polygon.polygon.points.push_back(point);
            point.x = 50;
            point.y = 1.875;
            point.z = 0;
            polygon.polygon.points.push_back(point);

            point.x = 20;
            point.y = 1.875;
            point.z = 0;
            polygon.polygon.points.push_back(point);
            point.x = 20;
            point.y = 5.63;
            point.z = 0;
            polygon.polygon.points.push_back(point);

            point.x = 50;
            point.y = 1.875;
            point.z = 0;
            polygon.polygon.points.push_back(point);
            point.x = 50;
            point.y = 5.63;
            point.z = 0;
            polygon.polygon.points.push_back(point);

            point.x = 20;
            point.y = 5.63;
            point.z = 0;
            polygon.polygon.points.push_back(point);
            point.x = 50;
            point.y = 5.63;
            point.z = 0;
            polygon.polygon.points.push_back(point);
        }
        else if (prediction.reject_status() & 16)
        {
            geometry_msgs::msg::Point32 point;
            point.x = -20;
            point.y = 1.875;
            point.z = 0;
            polygon.polygon.points.push_back(point);
            point.x = -50;
            point.y = 1.875;
            point.z = 0;
            polygon.polygon.points.push_back(point);

            point.x = -20;
            point.y = 1.875;
            point.z = 0;
            polygon.polygon.points.push_back(point);
            point.x = -20;
            point.y = 5.63;
            point.z = 0;
            polygon.polygon.points.push_back(point);

            point.x = -50;
            point.y = 1.875;
            point.z = 0;
            polygon.polygon.points.push_back(point);
            point.x = -50;
            point.y = 5.63;
            point.z = 0;
            polygon.polygon.points.push_back(point);

            point.x = -20;
            point.y = 5.63;
            point.z = 0;
            polygon.polygon.points.push_back(point);
            point.x = -50;
            point.y = 5.63;
            point.z = 0;
            polygon.polygon.points.push_back(point);
        }
        else if (prediction.reject_status() & 32)
        {
            geometry_msgs::msg::Point32 point;
            point.x = 20;
            point.y = -1.875;
            point.z = 0;
            polygon.polygon.points.push_back(point);
            point.x = 50;
            point.y = -1.875;
            point.z = 0;
            polygon.polygon.points.push_back(point);

            point.x = 20;
            point.y = -1.875;
            point.z = 0;
            polygon.polygon.points.push_back(point);
            point.x = 20;
            point.y = -5.63;
            point.z = 0;
            polygon.polygon.points.push_back(point);

            point.x = 50;
            point.y = -1.875;
            point.z = 0;
            polygon.polygon.points.push_back(point);
            point.x = 50;
            point.y = -5.63;
            point.z = 0;
            polygon.polygon.points.push_back(point);

            point.x = 20;
            point.y = -5.63;
            point.z = 0;
            polygon.polygon.points.push_back(point);
            point.x = 50;
            point.y = -5.63;
            point.z = 0;
            polygon.polygon.points.push_back(point);
        }
        else if (prediction.reject_status() & 64)
        {
            geometry_msgs::msg::Point32 point;
            point.x = -20;
            point.y = -1.875;
            point.z = 0;
            polygon.polygon.points.push_back(point);
            point.x = -50;
            point.y = -1.875;
            point.z = 0;
            polygon.polygon.points.push_back(point);

            point.x = -20;
            point.y = -1.875;
            point.z = 0;
            polygon.polygon.points.push_back(point);
            point.x = -20;
            point.y = -5.63;
            point.z = 0;
            polygon.polygon.points.push_back(point);

            point.x = -50;
            point.y = -1.875;
            point.z = 0;
            polygon.polygon.points.push_back(point);
            point.x = -50;
            point.y = -5.63;
            point.z = 0;
            polygon.polygon.points.push_back(point);

            point.x = -20;
            point.y = -5.63;
            point.z = 0;
            polygon.polygon.points.push_back(point);
            point.x = -50;
            point.y = -5.63;
            point.z = 0;
            polygon.polygon.points.push_back(point);
        }
        pub_reject_->publish(polygon);
    }
}

void DisplayNode::pub_lanes(google::protobuf::RepeatedPtrField<display_aviz::LaneLine> road_msg)
{
    visualization_msgs::msg::MarkerArray mArr;
    visualization_msgs::msg::Marker marker_delet;
    marker_delet.action = visualization_msgs::msg::Marker::DELETEALL;
    marker_delet.type = visualization_msgs::msg::Marker::CUBE;
    mArr.markers.push_back(marker_delet);

    for (int i = 0; i < road_msg.size(); i++)
    {
        // RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "====================lane====================");
        display_aviz::LaneLine lane = road_msg.Get(i);
        visualization_msgs::msg::Marker marker;
        marker.header.frame_id = FRAME_ID;
        marker.header.stamp = this->get_clock()->now();
        marker.ns = "lanes";
        marker.pose.orientation.w = 1.0;
        marker.action = marker.ADD;
        marker.id = ++id;
        string line_type_name = display_aviz::ENUM_LINE_TYPE_descriptor()->FindValueByNumber(lane.type())->name();
        // 不存在"DASHED"字符串，则表示实线否则虚线
        marker.type = line_type_name.find("DASHED") == string::npos ? marker.LINE_STRIP : marker.LINE_LIST;
        marker.color.a = 1.0;
        marker.scale.x = 0.1;
        int color = 1;
        if (line_type_name.find("DASHED") != string::npos)
        {
            color = 4;
        }
        else if (line_type_name.find("EDGE") != string::npos)
        {
            color = 3;
        }
        marker.color.r = this->line_colors[color][0];
        marker.color.g = this->line_colors[color][1];
        marker.color.b = this->line_colors[color][2];
        generate_points(marker, lane.start_point(), lane.end_point(), lane.curve());
        mArr.markers.push_back(marker);
    }
    pub_lane_->publish(mArr);
}

void DisplayNode::generate_points(visualization_msgs::msg::Marker &marker,
                                  display_aviz::FloatVector3 start_point,
                                  display_aviz::FloatVector3 end_point,
                                  display_aviz::Curve curve)
{
    // 设置起始点
    geometry_msgs::msg::Point start_p;
    start_p.x = start_point.x();
    start_p.y = start_point.y();
    start_p.z = 0.0;
    marker.points.push_back(start_p);
    // 设置中间点
    for (float start = start_point.x() + 1.0; start < end_point.x(); start++)
    {
        geometry_msgs::msg::Point middle_p;
        middle_p.x = start;
        middle_p.y = std::pow(start, 3.0) * curve.c3() + std::pow(start, 2.0) * curve.c2() + start * curve.c1() + curve.c0();
        middle_p.z = 0.0;
        marker.points.push_back(middle_p);
    }
    // 设置结束点
    geometry_msgs::msg::Point end_p;
    end_p.x = end_point.x();
    end_p.y = end_point.y();
    end_p.z = 0.0;
    marker.points.push_back(end_p);
    // 需要有偶数个点才能被正确渲染
    if (marker.points.size() % 2 != 0)
    {
        geometry_msgs::msg::Point end_p;
        end_p.x = end_point.x();
        end_p.y = end_point.y();
        end_p.z = 0.0;
        marker.points.push_back(end_p);
    }
}

void DisplayNode::pub_obstacle(google::protobuf::RepeatedPtrField<display_aviz::Obstacle> obstacles,
                               const char *pub_ob_type)
{
    visualization_msgs::msg::MarkerArray mArr;
    visualization_msgs::msg::Marker marker_delet;
    marker_delet.action = visualization_msgs::msg::Marker::DELETEALL;
    marker_delet.type = visualization_msgs::msg::Marker::CUBE;
    mArr.markers.push_back(marker_delet);

    for (display_aviz::Obstacle obstacle : obstacles)
    {
        visualization_msgs::msg::Marker marker;
        marker.header.frame_id = FRAME_ID;
        marker.header.stamp = this->get_clock()->now();
        marker.id = ++id;
        marker.type = visualization_msgs::msg::Marker::CUBE;
        marker.action = visualization_msgs::msg::Marker::ADD;
        marker.pose.position.x = obstacle.center_position().x();
        marker.pose.position.y = obstacle.center_position().y();
        marker.pose.position.z = obstacle.size().z() / 2;
        // 用四元数设置朝向
        tf2::Quaternion orientation;
        orientation.setRPY(0.0, 0.0, obstacle.yaw());
        marker.pose.orientation.x = orientation.getX();
        marker.pose.orientation.y = orientation.getY();
        marker.pose.orientation.z = orientation.getZ();
        marker.pose.orientation.w = orientation.getW();

        marker.scale.x = obstacle.size().x();
        marker.scale.y = obstacle.size().y();
        marker.scale.z = obstacle.size().z();

        if (pub_ob_type == DISPLAY_OBJ_MODEL)
        {
            int color;
            color = obstacle.serial_number() - 1;
            marker.color.r = box_model_colors[color][0];
            marker.color.g = box_model_colors[color][1];
            marker.color.b = box_model_colors[color][2];
            marker.scale.x = obstacle.size().x() + 1;
            marker.scale.y = obstacle.size().y() + 1;
            marker.scale.z = obstacle.size().z() + 1;
            if ((obstacle.class_type() == 2 || obstacle.class_type() == 5) &&
                (obstacle.serial_number() != 1 && obstacle.serial_number() != 2)) // BUS OR TRUCK
            {
                marker.color.r = 1.0;
                marker.color.g = 0.75;
                marker.color.b = 0.79;
            }
        }
        else
        {
            int color;
            if (pub_ob_type == DISPLAY_OBJ_VISION)
            {
                color = 0;
            }
            else if (pub_ob_type == DISPLAY_OBJ_FUSION)
            {
                color = 1;
            }
            else
            {
                color = 0;
            }
            marker.color.r = box_colors[color][0];
            marker.color.g = box_colors[color][1];
            marker.color.b = box_colors[color][2];
        }
        marker.color.a = 1.0;
        mArr.markers.push_back(marker);
        // 在box上显示编号
        visualization_msgs::msg::Marker text_1 = text_marker(obstacle);
        mArr.markers.push_back(text_1);
        visualization_msgs::msg::Marker text_2 = text_marker_information(obstacle);
        mArr.markers.push_back(text_2);
    }
    if (pub_ob_type == DISPLAY_OBJ_VISION)
    {
        pub_ob_vision_->publish(mArr);
    }
    else if (pub_ob_type == DISPLAY_OBJ_FUSION)
    {
        pub_ob_fusion_->publish(mArr);
    }
    else
    {
        pub_ob_model_->publish(mArr);
    }
}

void DisplayNode::pub_ego_car(string resource_path)
{
    visualization_msgs::msg::MarkerArray mArr;
    visualization_msgs::msg::Marker marker;
    marker.header.frame_id = EGO_FRAME_ID;
    marker.header.stamp = this->get_clock()->now();
    marker.id = 0;
    marker.type = visualization_msgs::msg::Marker::MESH_RESOURCE;
    marker.action = visualization_msgs::msg::Marker::MODIFY;
    marker.mesh_resource = "file://" + main_dir + resource_path; // 3D模型文件路径
    marker.mesh_use_embedded_materials = true;
    pub_tf(msg.ego.location.x, msg.ego.location.y, msg.ego.location.z);
    // 用四元数设置朝向
    tf2::Quaternion orientation;
    orientation.setRPY(0, 0.0, -180 * M_PI / 180.0);
    // orientation.setRPY(0, 0.0, 0);
    marker.pose.orientation.x = orientation.getX();
    marker.pose.orientation.y = orientation.getY();
    marker.pose.orientation.z = orientation.getZ();
    marker.pose.orientation.w = orientation.getW();
    // -1.5 4
    marker.pose.position.x = 4;
    marker.pose.position.y = 1.5;
    marker.pose.position.z = 0;
    marker.scale.x = msg.ego.size.x;
    marker.scale.y = msg.ego.size.y;
    marker.scale.z = msg.ego.size.z;
    marker.color.a = 1.0;
    marker.color.r = 0.53;
    marker.color.g = 0.80;
    marker.color.b = 0.92;
    mArr.markers.push_back(marker);
    pub_ego_car_->publish(mArr);
}

void DisplayNode::pub_ego_car()
{
    visualization_msgs::msg::MarkerArray mArr;
    visualization_msgs::msg::Marker marker;
    marker.header.frame_id = FRAME_ID;
    marker.header.stamp = this->get_clock()->now();
    marker.id = ++id;
    marker.type = visualization_msgs::msg::Marker::CUBE;
    marker.action = visualization_msgs::msg::Marker::ADD;
    marker.pose.position.x = 2;
    marker.pose.position.y = 0;
    marker.pose.position.z = 0.7;

    marker.scale.x = 4;
    marker.scale.y = 1.8;
    marker.scale.z = 1.4;

    marker.color.a = 1.0;
    marker.color.r = 0.53;
    marker.color.g = 0.80;
    marker.color.b = 0.92;
    mArr.markers.push_back(marker);
    pub_ego_car_->publish(mArr);
}

visualization_msgs::msg::Marker DisplayNode::text_marker(display_aviz::Obstacle obstacle)
{
    visualization_msgs::msg::Marker marker;
    marker.header.frame_id = FRAME_ID;
    marker.type = visualization_msgs::msg::Marker::TEXT_VIEW_FACING;
    marker.action = visualization_msgs::msg::Marker::ADD;
    marker.id = ++id;
    marker.pose.position.x = obstacle.center_position().x();
    marker.pose.position.y = obstacle.center_position().y();
    marker.pose.position.z = obstacle.center_position().z() + obstacle.size().z() / 2 + 0.1;
    marker.scale.x = obstacle.size().x() / 2;
    marker.scale.y = obstacle.size().y() / 2;
    marker.scale.z = obstacle.size().z() / 2;
    marker.color.a = 1.0;
    marker.color.r = 1.0;
    marker.color.g = 1.0;
    marker.color.b = 1.0;
    marker.text = obj_names[std::min((int)obstacle.class_type(), 11)];
    return marker;
}

visualization_msgs::msg::Marker DisplayNode::text_marker_sm(float position_x, float position_y, float position_z, std::string text)
{
    visualization_msgs::msg::Marker marker;
    marker.header.frame_id = FRAME_ID;
    marker.type = visualization_msgs::msg::Marker::TEXT_VIEW_FACING;
    marker.action = visualization_msgs::msg::Marker::ADD;
    marker.id = ++id;
    marker.pose.position.x = position_x;
    marker.pose.position.y = position_y;
    marker.pose.position.z = position_z;
    marker.scale.x = 30;
    marker.scale.y = 30;
    marker.scale.z = 2;
    marker.color.a = 1.0;
    marker.color.r = 1.0;
    marker.color.g = 1.0;
    marker.color.b = 1.0;
    marker.text = text;
    return marker;
}

visualization_msgs::msg::Marker DisplayNode::text_marker_information(display_aviz::Obstacle obstacle)
{
    visualization_msgs::msg::Marker marker;
    marker.header.frame_id = FRAME_ID;
    marker.type = visualization_msgs::msg::Marker::TEXT_VIEW_FACING;
    marker.action = visualization_msgs::msg::Marker::ADD;
    marker.id = ++id;
    marker.pose.position.x = obstacle.center_position().x() - obstacle.size().x() / 2;
    marker.pose.position.y = obstacle.center_position().y() - obstacle.size().y() / 2;
    marker.pose.position.z = obstacle.size().z();
    marker.scale.x = 0.6;
    marker.scale.y = 0.6;
    marker.scale.z = 0.6;
    marker.color.a = 1.0;
    marker.color.r = 1.0;
    marker.color.g = 1.0;
    marker.color.b = 1.0;
    marker.text = "id:" + std::to_string(obstacle.track_id()) + "\n" +
                  "x:" + std::to_string(obstacle.center_position().x()) + "\n" + "y:" + std::to_string(obstacle.center_position().y()) + "\n" +
                  // "v_x:"+std::to_string(obstacle.velocity().x())+"\n"+"v_y:"+std::to_string(obstacle.velocity().y())+"\n"+
                  "ttc:" + std::to_string(obstacle.ttc());
    return marker;
}

visualization_msgs::msg::Marker DisplayNode::text_marker_radar(display_aviz::RadarObject radar_object)
{
    visualization_msgs::msg::Marker marker;
    marker.header.frame_id = FRAME_ID;
    marker.type = visualization_msgs::msg::Marker::TEXT_VIEW_FACING;
    marker.action = visualization_msgs::msg::Marker::ADD;
    marker.id = ++id;
    marker.pose.position.x = radar_object.center_position().x() + 2;
    marker.pose.position.y = radar_object.center_position().y();
    marker.pose.position.z = radar_object.center_position().z();
    marker.scale.x = 1;
    marker.scale.y = 1;
    marker.scale.z = 1;
    marker.color.a = 1.0;
    marker.color.r = 1.0;
    marker.color.g = 1.0;
    marker.color.b = 1.0;
    marker.text = "ID:" + std::to_string(radar_object.track_id());
    return marker;
}

visualization_msgs::msg::Marker DisplayNode::text_marker_planning(display_aviz::Trajectory trajectory)
{
    visualization_msgs::msg::Marker marker;
    marker.header.frame_id = FRAME_ID;
    marker.type = visualization_msgs::msg::Marker::TEXT_VIEW_FACING;
    marker.action = visualization_msgs::msg::Marker::ADD;
    marker.id = ++id;
    marker.pose.position.x = trajectory.start_point().x() - 2;
    marker.pose.position.y = trajectory.start_point().y() - 1;
    marker.pose.position.z = trajectory.start_point().z();
    marker.scale.x = 1.2;
    marker.scale.y = 1.2;
    marker.scale.z = 1.2;
    marker.color.a = 1.0;
    marker.color.r = 1.0;
    marker.color.g = 1.0;
    marker.color.b = 1.0;
    marker.text = "C0:" + std::to_string(trajectory.curve().c0());
    return marker;
}

void DisplayNode::pub_predictions(display_aviz::Prediction prediction)
{
    visualization_msgs::msg::MarkerArray mArr;
    visualization_msgs::msg::Marker marker_delet;
    marker_delet.action = visualization_msgs::msg::Marker::DELETEALL;
    marker_delet.type = visualization_msgs::msg::Marker::CUBE;
    mArr.markers.push_back(marker_delet);

    for (display_aviz::PredictionObstacle po : prediction.obstacle_list())
    {
        visualization_msgs::msg::Marker marker;
        marker.header.frame_id = FRAME_ID;
        marker.header.stamp = this->get_clock()->now();
        marker.pose.orientation.w = 1.0;
        marker.action = marker.ADD;
        marker.id = ++id;
        marker.type = marker.LINE_STRIP;
        marker.color.a = 1.0;
        marker.scale.x = 0.1;
        marker.color.r = 1.0;
        marker.color.g = 1.0;
        marker.color.b = 0.0;
        for (display_aviz::FloatVector3 fv3 : po.position_list())
        {
            geometry_msgs::msg::Point p;
            p.x = fv3.x();
            p.y = fv3.y();
            p.z = 0.0;
            marker.points.push_back(p);
        }
        mArr.markers.push_back(marker);
    }
    pub_prediction_->publish(mArr);
}

void DisplayNode::pub_planning(display_aviz::Trajectory trajectory)
{
    visualization_msgs::msg::MarkerArray mArr;
    visualization_msgs::msg::Marker marker_delet;
    marker_delet.action = visualization_msgs::msg::Marker::DELETEALL;
    marker_delet.type = visualization_msgs::msg::Marker::CUBE;
    mArr.markers.push_back(marker_delet);

    visualization_msgs::msg::Marker marker;
    marker.header.frame_id = FRAME_ID;
    marker.header.stamp = this->get_clock()->now();
    marker.pose.orientation.w = 1.0;
    marker.action = marker.ADD;
    marker.id = ++id;
    marker.type = marker.LINE_STRIP;
    marker.color.a = 1.0;
    marker.scale.x = 0.1;
    marker.color.r = 0.53;
    marker.color.g = 0.80;
    marker.color.b = 0.92;
    marker.scale.x = 0.4;
    marker.scale.y = 0.4;
    marker.scale.z = 0.1;
    generate_points(marker, trajectory.start_point(), trajectory.end_point(), trajectory.curve());
    mArr.markers.push_back(marker);
    // 显示c0
    visualization_msgs::msg::Marker text = text_marker_planning(trajectory);
    mArr.markers.push_back(text);
    pub_planning_->publish(mArr);
}

void DisplayNode::pub_planning(vector<aviz::Point3d> &points)
{
    visualization_msgs::msg::MarkerArray mArr;
    visualization_msgs::msg::Marker marker_delet;
    marker_delet.action = visualization_msgs::msg::Marker::DELETEALL;
    marker_delet.type = visualization_msgs::msg::Marker::CUBE;
    mArr.markers.push_back(marker_delet);

    visualization_msgs::msg::Marker marker;
    marker.header.frame_id = FRAME_ID;
    marker.header.stamp = this->get_clock()->now();
    marker.pose.orientation.w = 1.0;
    marker.action = marker.ADD;
    marker.id = ++id;
    marker.type = marker.LINE_STRIP;
    marker.color.a = 1.0;
    marker.scale.x = 0.1;
    marker.color.r = 0.53;
    marker.color.g = 0.80;
    marker.color.b = 0.92;
    marker.scale.x = 0.4;
    marker.scale.y = 0.4;
    marker.scale.z = 0.1;
    for (auto p : points)
    {
        geometry_msgs::msg::Point point;
        point.x = p.x;
        point.y = p.y;
        point.z = 0.0;
        marker.points.push_back(point);
    }
    mArr.markers.push_back(marker);
    pub_planning_->publish(mArr);
}

void DisplayNode::pub_radar(google::protobuf::RepeatedPtrField<display_aviz::RadarObject> radarObjects)
{
    visualization_msgs::msg::MarkerArray mArr;
    visualization_msgs::msg::Marker marker_delet;
    marker_delet.action = visualization_msgs::msg::Marker::DELETEALL;
    marker_delet.type = visualization_msgs::msg::Marker::CUBE;
    mArr.markers.push_back(marker_delet);

    for (display_aviz::RadarObject radarObject : radarObjects)
    {
        visualization_msgs::msg::Marker marker;
        marker.header.frame_id = FRAME_ID;
        marker.header.stamp = this->get_clock()->now();
        marker.id = ++id;
        marker.type = visualization_msgs::msg::Marker::CUBE;
        marker.action = visualization_msgs::msg::Marker::ADD;
        marker.pose.position.x = radarObject.center_position().x();
        marker.pose.position.y = radarObject.center_position().y();
        marker.pose.position.z = radarObject.center_position().z();
        // 用四元数设置朝向
        tf2::Quaternion orientation;
        orientation.setRPY(0.0, 0.0, radarObject.yaw());
        marker.pose.orientation.x = orientation.getX();
        marker.pose.orientation.y = orientation.getY();
        marker.pose.orientation.z = orientation.getZ();
        marker.pose.orientation.w = orientation.getW();

        marker.scale.x = 1;
        marker.scale.y = 1;
        marker.scale.z = 1;

        marker.color.r = 1.0;
        marker.color.g = 0.5;
        marker.color.b = 0.0;
        marker.color.a = 1.0;
        mArr.markers.push_back(marker);
        // 在box上显示编号
        visualization_msgs::msg::Marker text = text_marker_radar(radarObject);
        mArr.markers.push_back(text);
    }
    pub_radar_->publish(mArr);
}

int DisplayNode::create_server()
{
    // socket
    int server = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (server == -1)
    {
        RCLCPP_ERROR_ONCE(rclcpp::get_logger("rclcpp"), "====ERROR: socket.====");
        exit(1);
    }
    // connect
    struct sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(PORT);
    serverAddr.sin_addr.s_addr = inet_addr(IP);
    if (bind(server, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) == -1)
    {
        perror("bind");
        RCLCPP_ERROR_ONCE(rclcpp::get_logger("rclcpp"), "====ERROR: bind.=====");
        exit(1);
    }
    RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "====The server is started.====");
    return server;
}

void DisplayNode::parser_message()
{
    std::ifstream f(main_dir + "/config/config.json");
    json data = json::parse(f);
    msg = data.get<aviz::PublishMessage>();
    is_simulation = msg.on;
    if (msg.on)
    {
        pub_ptr = std::make_shared<display_aviz::PublishMessage>();
        // lane
        for (int8_t i = 0; i < msg.lane.nums; i++)
        {
            display_aviz::LaneLine *laneLine = pub_ptr->add_road_msg();
            laneLine->mutable_start_point()->set_x(msg.lane.start_point.x);
            laneLine->mutable_start_point()->set_y(msg.lane.start_point.y + i * 3.75);
            laneLine->mutable_start_point()->set_z(msg.lane.start_point.z);

            laneLine->mutable_end_point()->set_x(msg.lane.end_point.x);
            laneLine->mutable_end_point()->set_y(msg.lane.end_point.y + i * 3.75);
            laneLine->mutable_end_point()->set_z(msg.lane.end_point.z);

            laneLine->mutable_curve()->set_c0(msg.lane.curve.c0 + i * 3.75);
            laneLine->mutable_curve()->set_c1(msg.lane.curve.c1);
            laneLine->mutable_curve()->set_c2(msg.lane.curve.c2);
            laneLine->mutable_curve()->set_c3(msg.lane.curve.c3);
            laneLine->set_type(static_cast<display_aviz::ENUM_LINE_TYPE>(msg.lane.types.at(i)));
        }

        // obj
        for (int32_t i = 0; i < msg.objs.size(); i++)
        {
            display_aviz::Obstacle *vision = pub_ptr->add_obstacles_vision_msg();
            vision->mutable_center_position()->set_x(msg.objs.at(i).location.x);
            vision->mutable_center_position()->set_y(msg.objs.at(i).location.y);
            vision->mutable_center_position()->set_z(msg.objs.at(i).location.z);
            vision->mutable_size()->set_x(msg.objs.at(i).size.x);
            vision->mutable_size()->set_y(msg.objs.at(i).size.y);
            vision->mutable_size()->set_z(msg.objs.at(i).size.z);
            vision->set_yaw(msg.objs.at(i).euler_angle.yaw);
        }
    }
}

void DisplayNode::pub_tf(double x, double y, double z)
{
    // 构建TF消息
    tf2_msgs::msg::TFMessage tf_msg;
    geometry_msgs::msg::TransformStamped transform;
    transform.header.frame_id = FRAME_ID;           // 固定坐标系
    transform.child_frame_id = EGO_FRAME_ID;        // 目标坐标系（与固定坐标系相同）
    transform.header.stamp = rclcpp::Clock().now(); // 当前时间戳

    // 设置平移和旋转信息
    transform.transform.translation.x = x; // 替换为目标坐标系的x平移
    transform.transform.translation.y = y; // 替换为目标坐标系的y平移
    transform.transform.translation.z = z; // 替换为目标坐标系的z平移

    transform.transform.rotation.x = 0.0; // 替换为目标坐标系的x旋转
    transform.transform.rotation.y = 0.0; // 替换为目标坐标系的y旋转
    transform.transform.rotation.z = 0.0; // 替换为目标坐标系的z旋转
    transform.transform.rotation.w = 1.0; // 替换为目标坐标系的w旋转

    tf_msg.transforms.push_back(transform);

    // 发布TF消息
    pub_tf_->publish(tf_msg);
}

int count_t = 0;
void DisplayNode::pub_traffic_light()
{
    visualization_msgs::msg::MarkerArray mArr;
    visualization_msgs::msg::Marker marker;
    marker.header.frame_id = FRAME_ID;
    marker.type = visualization_msgs::msg::Marker::MESH_RESOURCE;
    marker.action = visualization_msgs::msg::Marker::MODIFY;
    marker.ns = "traffic_light";

    string co = count_t % 2000 > 1000 ? "yellow" : "red";
    count_t++;
    marker.mesh_resource = "file://" + main_dir + "/meshes/Light_stands/" + co + ".dae";
    marker.mesh_use_embedded_materials = true;
    marker.id = ++id;
    // 用四元数设置朝向
    tf2::Quaternion orientation;
    orientation.setRPY(0, 0.0, 0);
    marker.pose.orientation.x = orientation.getX();
    marker.pose.orientation.y = orientation.getY();
    marker.pose.orientation.z = orientation.getZ();
    marker.pose.orientation.w = orientation.getW();
    marker.pose.position.x = 0;
    marker.pose.position.y = 35;
    marker.pose.position.z = 10;
    marker.scale.x = 4;
    marker.scale.y = 4;
    marker.scale.z = 4;

    mArr.markers.push_back(marker);
    pub_traffic_light_->publish(mArr);
}

void DisplayNode::set_planning_points(vector<aviz::Point3d> &points)
{
    this->points = points;
}

void DisplayNode::set_main_dir()
{
    // 获取当前源文件的路径，并转换为 std::string 对象
    const std::string currentSourcePath = __FILE__;
    // 提取所属目录的父目录路径
    main_dir = currentSourcePath.substr(0, currentSourcePath.find_last_of('/', currentSourcePath.find_last_of('/') - 1));
}

DisplayNode::DisplayNode(std::string task_name) : Node(task_name)
{
    server = create_server();
    set_main_dir();
    pub_lane_ = this->create_publisher<visualization_msgs::msg::MarkerArray>(DISPLAY_LANE, 10);
    pub_ob_vision_ = this->create_publisher<visualization_msgs::msg::MarkerArray>(DISPLAY_OBJ_VISION, 10);
    pub_ob_fusion_ = this->create_publisher<visualization_msgs::msg::MarkerArray>(DISPLAY_OBJ_FUSION, 10);
    pub_ob_model_ = this->create_publisher<visualization_msgs::msg::MarkerArray>(DISPLAY_OBJ_MODEL, 10);
    pub_radar_ = this->create_publisher<visualization_msgs::msg::MarkerArray>(DISPLAY_RADAR, 10);
    pub_prediction_ = this->create_publisher<visualization_msgs::msg::MarkerArray>(DISPLAY_PREDICTION, 10);
    pub_reject_ = this->create_publisher<geometry_msgs::msg::PolygonStamped>(DISPLAY_REJECT, 10);
    pub_planning_ = this->create_publisher<visualization_msgs::msg::MarkerArray>(DISPLAY_PLANNING, 10);
    pub_tf_sign_ = this->create_publisher<sensor_msgs::msg::Image>(DISPLAY_TFSIGN, 10);
    pub_ego_car_ = this->create_publisher<visualization_msgs::msg::MarkerArray>(DISPLAY_EGO_CAR, 10);
    pub_state_machine_ = this->create_publisher<visualization_msgs::msg::MarkerArray>(DISPLAY_STATE_MACHINE, 10);
    pub_traffic_light_ = this->create_publisher<visualization_msgs::msg::MarkerArray>(DISPLAY_TRAFFIC_LIGHT, 10);
    pub_tf_ = this->create_publisher<tf2_msgs::msg::TFMessage>(DISPLAY_TF, 10);

    voice_timer_group_ = this->create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);
    timer_group_ = this->create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);
    voice_broadcast_timer_ = this->create_wall_timer(5ms, std::bind(&DisplayNode::voice_broadcast_timer_callback, this), voice_timer_group_);
    timer_ = this->create_wall_timer(5ms, std::bind(&DisplayNode::timer_callback, this), timer_group_);
    clear_timer_ = this->create_wall_timer(300ms, std::bind(&DisplayNode::clear_timer_callback, this), timer_group_);
    this->init_load_images();
    parser_message();
}

DisplayNode::~DisplayNode()
{
    close(server);
}

int main(int argc, char **argv)
{
    GOOGLE_PROTOBUF_VERIFY_VERSION;
    rclcpp::init(argc, argv);
    auto node = std::make_shared<DisplayNode>("display_aviz");
    auto executor = std::make_shared<rclcpp::executors::MultiThreadedExecutor>();
    executor->add_node(node);
    executor->spin();
    /* 运行节点，并检测退出信号*/
    // rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
