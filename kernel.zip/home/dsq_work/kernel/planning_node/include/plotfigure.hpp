// #include <iostream>
// #include <math.h>
// #include "matplotlibcpp.h"
// namespace plt = matplotlibcpp;
// using namespace std;

// class PlotFigure
// {
// public:
//     PlotFigure(){};
//     ~PlotFigure(){};
//     void plottest();

// private:
// };