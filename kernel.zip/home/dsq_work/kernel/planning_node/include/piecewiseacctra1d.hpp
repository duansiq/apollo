#ifndef _PIECEWISEACCTRA_
#define _PIECEWISEACCTRA_
#include "pathpoint.hpp"
#include <vector>
#include <math.h>
#include <algorithm>
#include "liner_interpolation.hpp"
#include <iostream>
#include "constans.hpp"
#include "liner_interpolation.hpp"
#include "math_utils.h"


class PiecewiseAccelerationTrajectory1d
{
 public:

  PiecewiseAccelerationTrajectory1d(const double start_s, const double start_v);//创建分段加速轨迹

  virtual ~PiecewiseAccelerationTrajectory1d() = default;

  void AppendSegment(const double a, const double t_duration);

  double Evaluate_v(const double t) const;

 private:
  // accumulated s
  std::vector<double> s_;

  std::vector<double> v_;

  // accumulated t
  std::vector<double> t_;

  std::vector<double> a_;

} ;
#endif
