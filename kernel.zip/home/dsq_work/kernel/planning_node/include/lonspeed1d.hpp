#ifndef  _LONSPEED_
#define _LONSPEED_

typedef struct LONspeed
{
    double a0;
    double a1;
    double a2;
    double a3;
    double a4;
    double tmin;
    double tmax;

} LONspeed;
#endif