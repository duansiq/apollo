#ifndef _STBoundaryPoint_
#define _STBoundaryPoint_
typedef struct STBoundaryPoint
{
    double t;
    double sl;
    double su;
} STBoundaryPoint;
#endif