#ifndef _TEST_
#define _TEST_
#include <string.h>
#include "rclcpp/rclcpp.hpp"

using namespace std;

class Test
{

    public:
    // Test(){};
    // ~Test(){};
    // void test_include()
    // {
    //     cout << "include is ok" << endl;
    // };
        Test();
        ~Test();
        void test_include();

    private:
    /* data */
};

#endif