#ifndef _OBS_
#define _OBS_
typedef struct OBSPoint
{
    double x;
    double y;
    double theta;
    double velocity;
    double s;
    double l;
} OBSPoint;
#endif