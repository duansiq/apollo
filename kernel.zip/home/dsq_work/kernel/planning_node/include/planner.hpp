/******************************************************************************************
 * @FilePath: planner.hpp
 * @Author: wangyiwei
 * @Date: 2023-08-07 14:14:37
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2023-08-20 09:32:58
 * @Copyright: 2023 AICC Inc. All Rights Reserved.
 * @Input: 
 * @Output: 
 * @Descripttion: 
*****************************************************************************************/
#include <vector>
#include <mutex>
#include <math.h>

#include "obstacle.hpp"
#include "path_matcher.hpp"
#include "TrajectoryPoint.hpp"
#include "cartesian_frenet_converter.hpp"
#include "latpath1d.hpp"
#include "lonspeed1d.hpp"
#include "Trajectory1dGenerator.hpp"
#include "referenceline.hpp"
#include "pathpoint.hpp"
#include "trajectory_evaluator.hpp"
#include "collisionchecker.hpp"
#include "plotfigure.hpp"
#include "constraint_checker1d.hpp"
#include "end_condition_sampler.hpp"
#include "obs.hpp"
#include "path_time_graph.hpp"
#include "STBoundaryPoint.hpp"
#include "constans.hpp"
#include "pathpoint.hpp"
#include "StateMachine.hpp"
#include "VehicleReportMsg.h"
#include "math_utils.h"
#include "liner_interpolation.hpp"
#include <iomanip>
#include "planning_target.hpp"
#include "piecewiseacctra1d.hpp"


class Planner
{
private:
    /* data */
    Cartesian_Frenet_Converter cartesianfrenetconverter;
    Path_Matcher pathmatcher_;
    Trajectory1dGenerator trajectory1dgenerator;
    PathTimeGraph pathtimegraph;
    Constans constans;
    PlanningTarget planning_target;

    // vector<PathPoint> referenceline_points;
    vector<TrajectoryPoint> latpath_gcs;
    vector<vector<double>> obs_static_gcs_;
    Trajectory_Evaluator trajectory_evaluator;
    Collision_Checker collision_checker;
    LATpath latpath;
    LATpath lat_trajectory;
    Constraint_Checker1d latpointcal;

    EndConditionSampler endconditionsampler_;

    StateMachine state_;
    Obstacle obstacle_;
    PathPoint location_;
    std::vector<PathPoint> referenceline_;
    VehicleReportMsg vehicle_report_;

    std::deque<StateMachine> m_state_deque_;
    std::deque<Obstacle> m_obstacle_deque_;
    std::deque<PathPoint> m_location_deque_;
    std::deque<std::vector<PathPoint>> m_referenceline_deque_;
    std::deque<VehicleReportMsg> m_vehicle_report_deque_;

    std::mutex m_state_mutex_;
    std::mutex m_obstacle_mutex_;
    std::mutex m_location_mutex_;
    std::mutex m_referenceline_mutex_;
    std::mutex m_vehicle_report_mutex_;
    std::mutex m_trajectory_point_mutex_;

    int m_max_queue_depth_;
    PathPoint vehicle_state_;

    //0:ok, 0x01:location loss, 0x02: vehicle loss, 0x04: route loss, 0x08:state machine loss 
    int msg_state_;
    //local route
    std::vector<PathPoint> local_path_;


    int odom2local(PathPoint &ref,PathPoint &target_odom,PathPoint &target_local);
    int local2odom(PathPoint &ref,PathPoint &target_local,PathPoint &target_odom);
    int sync_msg();//step 1
    int update_smooth_line();//step 2
    int update_vehicle_state();//step 3
    int update_object_state();//step 4


public:
    Planner(/* args */);
    ~Planner();
    int set_reference_line(vector<PathPoint> &ref);
    int set_location(PathPoint &location);
    int set_object(Obstacle &obj);
    int set_state_machine(StateMachine &s);
    int set_vehicle_report(VehicleReportMsg &vr);
    int process();

    vector<PathPoint> get_referenceline_points() { return local_path_; };
    vector<TrajectoryPoint> get_latpath();
    // vector<TrajectoryPoint> get_latpath() { return latpath_gcs; };
    vector<vector<double>> get_obstacle() { return obs_static_gcs_; };
};

