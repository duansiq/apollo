#ifndef _PLANNINGTARGET_
#define _PLANNINGTARGET_
#include <vector>
#include <iostream>
#include <fstream>
#include <string.h>

class PlanningTarget
{

public:
    PlanningTarget() = default;
    PlanningTarget(bool has_stop_point,double &stop_point_s,double &cruise_speed);
    ~PlanningTarget(){};

    bool has_stop_point() const{ return has_stop_point_; }
    double stop_point_s() const{ return stop_point_s_; }
    double cruise_speed() const{ return cruise_speed_; }

private:
    bool has_stop_point_ = false;
    double stop_point_s_ = 5.0;
    double cruise_speed_ = 30.0;
};

#endif