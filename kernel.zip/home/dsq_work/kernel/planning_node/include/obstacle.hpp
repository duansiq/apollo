#ifndef _OBSTACLE_
#define _OBSTACLE_
#include <vector>
#include <iostream>
#include <fstream>
#include <string.h>
#include "path_matcher.hpp"
#include "SLPoint.hpp"
#include "cartesian_frenet_converter.hpp"
#include "box2d.h"
#include "polygon2d.h"
using namespace std;
class Obstacle
{

public:
    Obstacle() = default;
    Obstacle(const std::string &id,const std::vector<PathPoint> &trajectory,float length,float width);
    ~Obstacle(){};
    //接收车辆坐标系下的障碍物车辆坐标
    //接收全局坐标系下的障碍物车辆坐标
    //全局坐标系障碍物车辆载入，使用TXT载入数据
    // void get_obs_from_txt();
    // vector<vector<double>> get_obs_static() { return obs_static_gcs; };
    // vector<vector<double>> get_obs_dynamic() { return obs_dynamic_gcs; };
    // vector<vector<double>> get_obs_gcs() { return obs_gcs; };
    // vector<vector<SLPoint>> get_obs_predicte_sl() { return obs_dynamic_predict_sl; };
    // void obs_gcs_to_frenet();
    const std::string Id() const { return id_;}
    void SetId(const std::string &id) { id_ = id; }

    double speed() const { return speed_; }

    int32_t PerceptionId() const { return perception_id_; }

    bool IsStatic() const { return is_static_; }
    bool IsVirtual() const { return is_virtual_; }

    // AiccWayPoint GetPointAtTime(const double time) const;

    icvos::common::math::Box2d GetBoundingBox(
        const PathPoint &point,float w,float h) const;

    PathPoint GetPointAtTime(const double time) const;
private:
    std::string id_;
    int32_t perception_id_ = 0;
    bool is_static_ = false;
    bool is_virtual_ = false;
    double speed_ = 0.0;

    bool path_st_boundary_initialized_ = false;

    std::vector<PathPoint> trajectory_;
    // perception::PerceptionObstacle perception_obstacle_;
    icvos::common::math::Box2d perception_bounding_box_;
    icvos::common::math::Polygon2d perception_polygon_;

    // std::vector<ObjectDecisionType> decisions_;
    // std::vector<std::string> decider_tags_;
    // SLBoundary sl_boundary_;

    // STBoundary reference_line_st_boundary_;
    // STBoundary path_st_boundary_;

    // ObjectDecisionType lateral_decision_;
    // ObjectDecisionType longitudinal_decision_;

    // for keep_clear usage only
    bool is_blocking_obstacle_ = false;

    bool is_lane_blocking_ = false;

    bool is_lane_change_blocking_ = false;

    bool is_caution_level_obstacle_ = false;

    double min_radius_stop_distance_ = -1.0;

    // vector<vector<double>> obs_gcs;
    // vector<vector<double>> obs_static_gcs;
    // vector<vector<double>> obs_dynamic_gcs;
    // vector<vector<double>> obs_static_frenet;
    // vector<vector<SLPoint>> obs_dynamic_predict_sl;
    // Cartesian_Frenet_Converter cartesion2frenet;
};

#endif