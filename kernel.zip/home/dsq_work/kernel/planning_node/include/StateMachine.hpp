#ifndef __STATEMACHINE__
#define __STATEMACHINE__
typedef struct StateMachine
{
    float set_speed;
    int run_state;//0:stop,1:go
    float speed_limit;
    int plan_mode;//0:cruise, 1:lanechange , 2:stop
    int run_flag;
}StateMachine;

#endif