#ifndef _ST_POINT_
#define _ST_POINT_
typedef struct STPoint
{
    double s;
    double ds;
    double dds;
    double t;
} STPoint;

#endif