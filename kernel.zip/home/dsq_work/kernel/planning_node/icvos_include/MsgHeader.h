#ifndef __MSGHEADER_H__
#define __MSGHEADER_H__
#include "stdint.h"
typedef char short_string[100];
typedef float float_array[256];
typedef uint8_t uint8_array[256];
typedef float float_array_3[3];
typedef double double_array_3[3];
typedef char char_array_32[32];
typedef float float_array_32[32];
typedef double double_array_32[32];
typedef uint8_t unit8_array_620000[620000];
typedef int32_t int32_array_32[32];
typedef struct aicc_MsgHeader{
    short_string type_name;
    uint32_t seq;
    uint64_t sys_stamp;
    uint64_t data_stamp;
}MsgHeader;

#endif // __MSGHEADER_H__
