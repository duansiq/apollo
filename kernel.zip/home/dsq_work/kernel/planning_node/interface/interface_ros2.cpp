// 角度使用弧度
// 坐标系使用自车坐标系
// 速度使用m/s

#include "rclcpp/rclcpp.hpp"
#include "visualization_msgs/msg/marker.hpp"
#include "visualization_msgs/msg/marker_array.hpp"
#include "nav_msgs/msg/path.hpp"
#include "planner.hpp"
#include <functional>
#include <memory>

using std::placeholders::_1;

class PlanningNode : public rclcpp::Node
{
private:
    /* data */
    rclcpp::Subscription<visualization_msgs::msg::MarkerArray>::SharedPtr lane_,ob_vision_;
    rclcpp::Publisher<nav_msgs::msg::Path>::SharedPtr publisher_latpath_;             // 发布者
    rclcpp::TimerBase::SharedPtr timer1;
    std::shared_ptr<Planner> planner_ptr_;


   void lane_callback(const visualization_msgs::msg::MarkerArray::SharedPtr msg) ;
   void obj_callback(const visualization_msgs::msg::MarkerArray::SharedPtr msg) ;
   void timer_process(void);
public:
    PlanningNode(std::string task_name);
    ~PlanningNode();
};

PlanningNode::PlanningNode(std::string task_name):Node(task_name)
{
    lane_ = this->create_subscription<visualization_msgs::msg::MarkerArray>("/display_lane",1,std::bind(&PlanningNode::lane_callback,this,_1));
    ob_vision_ = this->create_subscription<visualization_msgs::msg::MarkerArray>("/display_obj_vision_",1,std::bind(&PlanningNode::obj_callback,this,_1));
    publisher_latpath_ = this->create_publisher<nav_msgs::msg::Path>("/latpath", 10);
    timer1 = this->create_wall_timer(100ms,std::bind(&PlanningNode::timer_process,this));
    planner_ptr_ = std::make_shared<Planner>();

}
void PlanningNode::timer_process(void)
{
    //state machine
    StateMachine state_machine = {0};
    state_machine.plan_mode = 1;
    planner_ptr_->set_state_machine(state_machine);
    //location
    PathPoint pp = {0};
    pp.x = 0;
    pp.y = 0;
    pp.t = 0;
    planner_ptr_->set_location(pp);
    //object

    //vehicle report
    VehicleReportMsg vr = {0};
    vr.chassis_report.velocity = 30/3.6;
    vr.chassis_report.steer_angle = 0;
    vr.chassis_report.ego_motion.ax = 0;
    planner_ptr_->set_vehicle_report(vr);
    

    planner_ptr_->process();
    std::cout << "timer_process " << std::endl;

    auto latpathposes = nav_msgs::msg::Path();
    auto latpath_gcs = planner_ptr_->get_latpath();
    if(latpath_gcs.size() > 1)
    {
        for (auto latpathpoint : latpath_gcs)
        {
            geometry_msgs::msg::PoseStamped point;
            point.header.frame_id = "/base_link";
            point.pose.position.x = latpathpoint.x;
            point.pose.position.y = latpathpoint.y;
            point.pose.position.z = 0.;
            // std::cout << "x " << latpathpoint.x << " y: " << latpathpoint.y << std::endl;
            latpathposes.poses.emplace_back(point);
        }

        latpathposes.header.frame_id = "/base_link";
        publisher_latpath_->publish(latpathposes);
    }
    else
    {
        std::cout << "latpath_gcs size is small " << std::endl;
    }
}

void PlanningNode::lane_callback(const visualization_msgs::msg::MarkerArray::SharedPtr msg)
{
    // std::cout << "get lane info " << msg->markers.size() << std::endl;
    std::vector<std::vector<PathPoint> > points_total;
    for(int i = 0; i < msg->markers.size();i ++)
    {
      std::vector<PathPoint> points;
      for (int j = 0; j < msg->markers[i].points.size(); j++)
      {
          PathPoint p_tmp;
          p_tmp.x = msg->markers[i].points[j].x;
          p_tmp.y = msg->markers[i].points[j].y;
          points.push_back(p_tmp);
        }
        points_total.push_back(points);
    }

    if(points_total.size() < 2)
    {
        std::cout << "can not get lane data! " << std::endl;
        return ;
    }
    if(points_total[2].size() != points_total[1].size())
    {
        // std::cout << "lane data size is not equ! " << points_total[0].size() << " \t " << points_total[1].size() << std::endl;
        return ;
    }
    //first lane
    std::vector<PathPoint> points;
    points.clear();
    for(int i =0; i < points_total[1].size();i ++)
    {
        PathPoint tmp;
        tmp.x = points_total[2][i].x ;
        tmp.y = (points_total[2][i].y + points_total[3][i].y)/2.0;
        points.push_back(tmp);
        // std::cout << "points.x " << points.back().x << " points.y " << points.back().y << std::endl;
    }
    // auto func_distance = [](const PathPoint &p1, const PathPoint &p2)
    // {
    //     double dx = p1.x - p2.x;
    //     double dy = p1.y - p2.y;
    //     return std::sqrt(dx * dx + dy * dy);
    // };
    // points[0].s = 0;
    // for (int i = 1; i < points.size(); i++)
    // {
    //     points[i].s = func_distance(points[i],points[i - 1]);
    // }
    // std::cout << "points " << points.size() << std::endl;

    planner_ptr_->set_reference_line(points);
    return ;
}

void PlanningNode::obj_callback(const visualization_msgs::msg::MarkerArray::SharedPtr msg)
{
    Obstacle obj_tmp;
    return ;
}

PlanningNode::~PlanningNode()
{
}

int main(int argc,char **argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<PlanningNode>("planning_node");
    auto executor = std::make_shared<rclcpp::executors::MultiThreadedExecutor>();
    executor->add_node(node);
    executor->spin();
    rclcpp::shutdown();
    
    return 0;
}