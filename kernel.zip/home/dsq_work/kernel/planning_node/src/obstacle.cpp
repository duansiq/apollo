#include "obstacle.hpp"
#include "math_utils.h"

icvos::common::math::Box2d Obstacle::GetBoundingBox(
        const PathPoint &point,float w,float h) const
{
    return icvos::common::math::Box2d({point.x,point.y},point.theta,h,w);
}

PathPoint Obstacle::GetPointAtTime(const double time) const
{
    if(trajectory_.size() < 2)
    {
        return PathPoint{0,0,0};
    }
    else
    {
        auto comp = [](const PathPoint p,const double time){
            return p.t < time;
        };
        auto it_lower = std::lower_bound(trajectory_.begin(),trajectory_.end(),time,comp);
        if(it_lower == trajectory_.begin())
        {
            return *trajectory_.begin();
        }
        else if(it_lower == trajectory_.end())
        {
            return *trajectory_.rbegin();
        }
        return icvos::common::math::InterpolateUsingLinearApproximation(*(it_lower - 1),*it_lower,time);
    }

}

Obstacle::Obstacle(const std::string &id,const std::vector<PathPoint> &trajectory,float length,float width)
{
    id_ = id;
    trajectory_ = trajectory;

    double cumulative_s = 0.0;
    if(trajectory_.size() > 0)
    {
        trajectory_[0].s = 0.0;
    }
    for(int i = 1; i < trajectory_.size(); i++)
    {
        auto prev = trajectory_[i - 1];
        auto cur = trajectory_[i];
        cumulative_s += std::hypot(prev.x - cur.x,prev.y - cur.y);
        trajectory_[i].s = cumulative_s;
    }

}
// 计算txt总行数
// int cal_txt_row()
// {
//     int row_index = 0; // 存储总的txt行数
//     // char line[512];    // 每行最大字符数
//     string temp; // 存放每行的字符
//     ifstream obs_read;
//     obs_read.open("/share/pilot/kernel/cpp_pubsub/txt/staticobs.txt", ios::in);

//     if (!obs_read.is_open())
//     {
//         cout << "Unable to open staticobs.txt";
//         exit(1);
//     }
//     else
//     {
//         while (getline(obs_read, temp))
//         {
//             row_index++;
//         }
//     }
//     obs_read.close();
//     return row_index;
// }

// void Obstacle::get_obs_from_txt()
// {
//     int txt_num = cal_txt_row();
//     if (txt_num != 0)
//     {
//         vector<vector<double>> obs(txt_num, vector<double>(4, 0));

//         ifstream obs_read;
//         obs_read.open("/share/pilot/kernel/cpp_pubsub/txt/staticobs.txt");

//         if (!obs_read.is_open())
//         {
//             cout << "Unable to open staticobs.txt";
//             exit(1);
//         }

//         for (int i = 0; i < txt_num; i++)
//         {
//             obs_read >> obs[i][0]; //x
//             obs_read >> obs[i][1]; //y
//             obs_read >> obs[i][2]; //heading
//             obs_read >> obs[i][3]; //v
//         }
//         obs_read.close();
//         obs_gcs.clear();
//         for (auto obs_ : obs)
//         {
//             obs_gcs.emplace_back(obs_);
//         }
//     }
// }


