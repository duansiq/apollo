#include "piecewiseacctra1d.hpp"

PiecewiseAccelerationTrajectory1d::PiecewiseAccelerationTrajectory1d(const double start_s, const double start_v)
{
    s_.push_back(start_s);
    v_.push_back(start_v);
    a_.push_back(0.0);
    t_.push_back(0.0);
}

void PiecewiseAccelerationTrajectory1d::AppendSegment(const double a,const double t_duration)
{
  double s0 = s_.back();
  double v0 = v_.back();
  double t0 = t_.back();

  double v1 = v0 + a * t_duration;

  double delta_s = (v0 + v1) * t_duration * 0.5;//时间间隔小近似看做匀加速度速度
  double s1 = s0 + delta_s;
  double t1 = t0 + t_duration;

  s1 = std::max(s1, s0);
  s_.push_back(s1);
  v_.push_back(v1);
  a_.push_back(a);
  t_.push_back(t1);
}

double PiecewiseAccelerationTrajectory1d::Evaluate_v(const double t) const
{
  auto it_lower = std::lower_bound(t_.begin(), t_.end(), t);
  auto index = std::distance(t_.begin(), it_lower);

  double v0 = v_[index - 1];
  double t0 = t_[index - 1];

  double v1 = v_[index];
  double t1 = t_[index];

  double v = icvos::common::math::slerp(v0, t0, v1, t1, t);
  return v;
}
