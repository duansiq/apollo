#include "test.hpp"
Test::Test() {}
Test::~Test() {}
void Test::test_include()
{
    cout << "include is ok 123" << endl;
}