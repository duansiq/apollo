/******************************************************************************************
 * @FilePath: planner.cpp
 * @Author: wangyiwei
 * @Date: 2023-08-07 14:13:46
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2023-08-23 20:04:21
 * @Copyright: 2023 AICC Inc. All Rights Reserved.
 * @Input: 
 * @Output: 
 * @Descripttion: 
*****************************************************************************************/
#include "planner.hpp"

Planner::Planner(/* args */)
{
    m_max_queue_depth_ = 10;
    msg_state_ = 0;
}

int Planner::sync_msg()
{
    {//reference line update && convert line from enu to vcs 
        std::lock_guard<std::mutex> lock(m_referenceline_mutex_);
        if(m_referenceline_deque_.empty())
        {
            std::cout << "have no reference line" << std::endl;
            msg_state_ |= 0x04;
        }
        else
        {
            referenceline_ = m_referenceline_deque_.back();
            if(m_referenceline_deque_.size() > 1)
                m_referenceline_deque_.pop_front();
            msg_state_ &= ~0x04;
            //todo:: convert line from enu to vcs
        }
    }
    {//state machine update
        std::lock_guard<std::mutex> lock(m_state_mutex_);
        if(m_state_deque_.empty())
        {
            std::cout << "have no state machine" << std::endl;
            msg_state_ |= 0x08;
        }
        else
        {
            state_ = m_state_deque_.back();
            m_state_deque_.pop_front();
            msg_state_ &= ~0x08;
            //todo: update data from timestamp
        }
    }
    {//location update
        std::lock_guard<std::mutex> lock(m_location_mutex_);
        if(m_location_deque_.empty())
        {
            std::cout << "have no location data" << std::endl;
            msg_state_ |= 0x01;
        }
        else
        {
            location_ = m_location_deque_.back();
            m_location_deque_.pop_front();
            msg_state_ &= ~0x01;
            //todo: update data from timestamp
        }
    }
    {//object update
        std::lock_guard<std::mutex> lock(m_obstacle_mutex_);
        if(m_obstacle_deque_.empty())
        {
            std::cout << "have no object data" << std::endl;
        }
        else
        {
            obstacle_ = m_obstacle_deque_.back();
            m_obstacle_deque_.pop_front();
            //todo: update data from timestamp
        }
    }
    {//vehicle report update
        std::lock_guard<std::mutex> lock(m_vehicle_report_mutex_);
        if(m_vehicle_report_deque_.empty())
        {
            std::cout << "have no vehicle report data" << std::endl;
            msg_state_ |= 0x02;
        }
        else
        {
            vehicle_report_ = m_vehicle_report_deque_.back();
            m_vehicle_report_deque_.pop_front();
            msg_state_ &= ~0x02;
            //todo: update data from timestamp
        }
    }
	return 0;
}

int Planner::odom2local(PathPoint &ref, PathPoint &target_odom, PathPoint &target_local)
{
    double delta_x = target_odom.x - ref.x;
    double delta_y = target_odom.y - ref.y;
    double ego_yaw_rad = ref.theta ;
    double ego_x = delta_x * std::cos(ego_yaw_rad) + delta_y * std::sin(ego_yaw_rad);
    double ego_y = -delta_x * std::sin(ego_yaw_rad) + delta_y * std::cos(ego_yaw_rad);
    double ego_theta = target_odom.theta - ref.theta;
    target_local.x = ego_x;
    target_local.y = ego_y;
    target_local.theta = ego_theta;
    // std::cout << "ref x: " << ref.x << " y " << ref.y << " theta " << ref.theta << std::endl;
    // std::cout << "x " << target_odom.x << " y " << target_odom.y << " theta " << target_odom.theta  << std::endl;
    // std::cout << "x " << target_local.x << " y " << target_local.y << " theta " << target_local.theta  << std::endl;
    return 0;
}

int Planner::local2odom(PathPoint &ref,PathPoint &target_local,PathPoint &target_odom)
{
    double ego_yaw_rad = ref.theta;
    double ego_x = target_local.x * std::cos(ego_yaw_rad) - target_local.y * std::sin(ego_yaw_rad);
    double ego_y = target_local.x * std::sin(ego_yaw_rad) + target_local.y * std::cos(ego_yaw_rad);
    ego_x += ref.x;
    ego_y += ref.y;
    double ego_theta = target_local.theta + ref.theta;
    target_odom.x = ego_x;
    target_odom.y = ego_y;
    target_local.theta = ego_theta;
    return 0;
}

int Planner::update_object_state(void)
{

    return 0;
}

int Planner::update_vehicle_state(void)
{
    vehicle_state_.x = 0;
    vehicle_state_.y = 0;
    vehicle_state_.theta = 0;
    vehicle_state_.a = vehicle_report_.chassis_report.ego_motion.ax;
    vehicle_state_.v = vehicle_report_.chassis_report.velocity;
    //r=L/sin(theta) theta = steer_angle * rate_speed;
    float steer_ratio = 28.5;//qirui
    vehicle_state_.kappa = std::sin(vehicle_report_.chassis_report.steer_angle/steer_ratio / 180.0 * M_PI);

    return 0;
}
int Planner::update_smooth_line(void)
{
    std::cout << "update_smooth_line: " << std::endl;
    if(msg_state_)
    {
        // std::cout << "msg is error 0x" << std::hex << std::setiosflags(ios::uppercase) << std::setfill('0') << std::setw(2) << msg_state_ << std::endl;
        return -1;
    }
    float current_velocity = vehicle_report_.chassis_report.velocity;
    float front_distance = 30 + current_velocity * 3.6 * 1.1;
    int match_index = 0;
    std::cout << "to matched_point: " << referenceline_.size() << 
    " x: " << location_.x << " y: " << location_.y <<  
    " theta " << location_.theta << std::endl;
    PathPoint matched_point = pathmatcher_.MatchToPath(
        referenceline_, location_.x, location_.y,match_index);
    // 将全局坐标系转换成自车坐标系
    // PathPoint local_tmp = {0};//初始点
    std::vector<PathPoint> path_intervel;
    // path_intervel.push_back(referenceline_[match_index]);
    //     std::cout << "path_intervel x " << path_intervel.back().x << " y " << path_intervel.back().y << " s " 
    //     << " theta " << path_intervel.back().theta 
    //     << " s " << path_intervel.back().s << " a " << path_intervel.back().a << std::endl;
    float current_dis = 0;
    std::cout << "match_index: " << match_index << std::endl;
    for(int index = match_index; current_dis < front_distance && index < referenceline_.size();index++)
    {
        PathPoint local_tmp = {0};
        odom2local(location_, referenceline_[index],local_tmp);
        //s kappa a 
        if(!path_intervel.empty())
        {
            PathPoint last_point = path_intervel.back();
            current_dis += std::hypot(local_tmp.x - last_point.x, local_tmp.y - last_point.y);
        }
            local_tmp.s = current_dis;
        path_intervel.push_back(local_tmp);
        // std::cout << "local_tmp x " << local_tmp.x << " y " << local_tmp.y << " s " 
        // << " theta " << local_tmp.theta 
        // << " s " << local_tmp.s << " a " << local_tmp.a << std::endl;

        // std::cout << "referenceline x " << referenceline_[index].x << " y " << referenceline_[index].y << " s " 
        // << " theta " << referenceline_[index].theta 
        // << " s " << referenceline_[index].s << " a " << referenceline_[index].a << std::endl;
        // std::cout << "path_intervel x " << path_intervel.back().x << " y " << path_intervel.back().y << " s " 
        // << " theta " << path_intervel.back().theta 
        // << " s " << path_intervel.back().s << " a " << path_intervel.back().a << std::endl;

        // PathPoint cur_point = path_intervel.back();
        // float diff_x = cur_point.x - last_point.x;
        // float diff_y = cur_point.y - last_point.y;

        // float dis = std::sqrt(diff_x * diff_x + diff_y * diff_y);
        // current_dis += path_intervel.back().s;
    }
    std::cout << " path_intervel size: " << path_intervel.size() << std::endl;
    for(int i = 0; i < path_intervel.size(); i++)
    {
        std::cout << "path_intervel x " << path_intervel[i].x << " y " << path_intervel[i].y << " s " 
        << " theta " << path_intervel[i].theta 
        << " s " << path_intervel[i].s << " a " << path_intervel[i].a << std::endl;

    }

    //局部参考线的等间距采样（平滑）
    const double interval = 0.2;//采样点距离
    // std::vector<float> anchor_s;
    auto it_lower = path_intervel.begin();
    local_path_.clear();
    // local_path_.push_back(path_intervel.front());
    // std::cout << "x " << it_lower->x << " y " << it_lower->y << " s " << it_lower->s << " a " << it_lower->a << std::endl;
    // it_lower++;
    // std::cout << "x " << it_lower->x << " y " << it_lower->y << " s " << it_lower->s << " a " << it_lower->a << std::endl;
    // it_lower = path_intervel.begin();
    for(float s = path_intervel.front().s; s < path_intervel.back().s; s+=interval)
    {
        // std::cout << "x " << it_lower->x << " y " << it_lower->y << " s " << it_lower->s << " a " << it_lower->a << std::endl;
        if(s > (it_lower + 1)->s)it_lower++;
        if(s > it_lower->s && s < (it_lower + 1)->s)
        {
            auto path_tmp = pathmatcher_.linerinterpolation.InterpolateUsingLinearApproximation(*(it_lower), *(it_lower + 1), s);
            path_tmp.s -= path_intervel.front().s;
            local_path_.push_back(path_tmp);
        }
    }
    std::cout << " local_path_ size: " << local_path_.size() << std::endl;

    return 0;
}

// 主函数
/*
    //1、参考线获取
    //2、匹配点计算
    //3、初始化坐标系Frenet，计算起始点坐标
    //4、获取当前时刻
    //5、障碍车投影 轨迹预测
    //6、构造pathtimegraph
    //7、设置速度限制
    //8、规划目标点获取
    //9、横向纵向轨迹簇生成
    //10、一维轨迹簇的可用性筛选
    //11、轨迹对的的匹配并计算总cost
    //12、选取最小cost的轨迹对合并
    //13、轨迹的可用性判断 横纵向加速度 曲率
    //14、碰撞检测
*/
int Planner::process()
{
    sync_msg();//step 1
    std::cout << "step 1 " << msg_state_ << std::endl;
    if(msg_state_)
    {
        std::cout << "msg is error 0x" << std::hex << std::setiosflags(ios::uppercase) << std::setfill('0') << std::setw(2) << msg_state_ << std::endl;
        return -1;
    }
    //to be continue 轨迹拼接
    
    update_smooth_line();//step 2
    std::cout << "step 2 " << std::endl;
    update_vehicle_state();//step 3
    std::cout << "step 3 " << std::endl;
    
    // 4、匹配点计算
    int match_index = 0;
    PathPoint matched_point = pathmatcher_.MatchToPath(
        local_path_, vehicle_state_.x, vehicle_state_.y,match_index);
    std::cout << "step 4 " << std::endl;
    // 5、初始化坐标系Frenet，计算起始点坐标
    array<double, 3> init_s{0, 0, 0};
    array<double, 3> init_d{0, 0, 0};
    cartesianfrenetconverter.cartesian_to_frenet(matched_point.s, matched_point.x, matched_point.y,
                                                 matched_point.theta, matched_point.kappa, matched_point.dkappa,
                                                 vehicle_state_.x, vehicle_state_.y,
                                                 vehicle_state_.v, vehicle_state_.a,
                                                 vehicle_state_.theta,
                                                 vehicle_state_.kappa, &init_s, &init_d);

    std::cout << "step 5 " << std::endl;
    // 6、障碍物投影到frenet
    vector<vector<double>> obs_static_frenet;
    vector<vector<double>> obs_dynamic_frenet;
    update_object_state();
    // 7、设置速度
    float set_speed = 30/3.6;
    // 8、规划目标点获取,应该是一些规划目标的信息，终点，巡航速度等，暂不设置

    // 9、横向纵向轨迹簇生成
    vector<LATpath> lat_trajectory1d_bundle;
    endconditionsampler_.Init(init_s, init_d);
    // 9.1横向轨迹簇生成
    // 横向规划终点采样
    vector<pair<vector<double>, double>> lat_end_conditions;
    lat_end_conditions = endconditionsampler_.SampleLatEndConditions();
    // 横向规划轨迹簇
    trajectory1dgenerator.GenerateLateralTrajectoryBundle(init_s, init_d, lat_end_conditions, lat_trajectory1d_bundle);

    // 9.2纵向速度规划
    vector<LONspeed> lon_trajectory1d_bundle;
    vector<pair<vector<double>, double>> lon_end_conditions;
    vector<double> end_ds_candidates;
    vector<double> end_t_candidates;
    // int plan_mode = 0; // 巡航
    int plan_mode = state_.plan_mode; //变道
    // int plan_mode = 2; //停车

    // 规划末点采样
    double s_start = local_path_[0].s;
    double s_end = local_path_.back().s;
    double t_start = 0.;
    double t_end = constans.FLAGS_trajectory_time_length;
    //path time graph 待添加。
    pathtimegraph.Init(obs_dynamic_frenet, local_path_, s_start, s_end, t_start, t_end, init_d , init_s);
    vector<STBoundaryPoint> STboundarypoint=pathtimegraph.get_STBoundary();
    // if(!STboundarypoint.empty())
    // {
    //     for(auto p:STboundarypoint)
    //     {
    //         cout << "t: " << p.t << " sl: " << p.sl << " su: " << p.su << endl;
    //     }
    // }
    double v_upper; // 道路限速
    if (plan_mode == 0)
    {
        //*巡航速度规划末点采样
        v_upper = state_.speed_limit; // 道路限速
        lon_end_conditions = endconditionsampler_.SampleLonEndConditionsForCruising(v_upper);
        trajectory1dgenerator.GenerateSpeedProfilesForCruising(init_s, lon_end_conditions, lon_trajectory1d_bundle);
    }
    else if (plan_mode == 1)
    {
        //*变道速度规划末点采样
        lon_end_conditions = endconditionsampler_.SampleLonEndConditionsForLaneChange(STboundarypoint ,v_upper);
        for(auto condition:lon_end_conditions)
        {
            cout << "lon_end_conditions: s: " << condition.first[0] << " v: " 
            << condition.first[1] << " a: " << condition.first[0] << " t: " << condition.second << endl;
        }
    }
    else
    {
        //*停车速度规划末点采样
        double stop_point_s=10;
        lon_end_conditions = endconditionsampler_.SampleLonEndConditionsForStopping(stop_point_s);
    }
    //*巡航速度规划
    //*前方参考线距离内无车
    //*前方参考线距离内有车无车判断
    //*判断障碍物在参考线的投影上
    //*变道速度规划

    //*停车速度规划
    // if (!lon_trajectory1d_bundle.empty())
    // {
    //     cout << " speed plan size: " << lon_trajectory1d_bundle.size() << endl;
    //     cout << " speed plan size: " << lon_trajectory1d_bundle.size() << endl;
    //     cout << " speed plan size: " << lon_trajectory1d_bundle.size() << endl;

    //     for (auto lon_tra : lon_trajectory1d_bundle)
    //     {
    //         cout << lon_tra.a0 << " " << lon_tra.a1 << " " << lon_tra.a2 << " " << lon_tra.a3 << " " << lon_tra.a4 << " " << lon_tra.tmin << " " << lon_tra.tmax << endl;
    //     }
    // }

    // 10、一维轨迹簇的可用性筛选
    trajectory_evaluator.TrajectoryEvaluator(init_s, planning_target, lon_trajectory1d_bundle, lat_trajectory1d_bundle, pathtimegraph, local_path_);
    cout << " before collision path number: " << trajectory_evaluator.num_of_trajectory() << endl;

    // collision_checker.BuildPredictedEnvironment(obs_gcs, obs_frenet, init_s[0], init_d[0], referenceline_);
    // 14、碰撞检测
    bool latplanok = false;
    while (trajectory_evaluator.has_more_trajectory())
    {
        auto cost = trajectory_evaluator.gettop_cost();
        auto lat_trajectory = trajectory_evaluator.gettop_trajectory();
        if (collision_checker.InCollision(obs_static_frenet, lat_trajectory, 2, 5, init_s))
        {
            cout << " top cost: " << cost << endl;
            latplanok = true;
            latpath = lat_trajectory;
            break;
        }
        else
            continue;
    }

    cout << " after collision path number: " << trajectory_evaluator.num_of_trajectory() << endl;
    cout << "local path: " << latpath.a0 << " " << latpath.a1 << " " << latpath.a2 << " "
         << latpath.a3 << " " << latpath.a4 << " " << latpath.a5 << " " << latpath.smin << " "
         << latpath.smax << " " << latpath.end_s << " " << latpath.end_l << endl;

    // while (trajectory_evaluator.has_more_trajectory())
    // {
    //     auto cost = trajectory_evaluator.gettop_cost();
    //     auto lat_trajectory = trajectory_evaluator.gettop_trajectory();
    //     cout << " cost : " << cost << " lat_trajectory " << lat_trajectory.end_s << " " << lat_trajectory.end_l << endl;
    // }

    // 坐标系转化为笛卡尔坐标系
    if (latplanok)
    {
        // 五次多项式系数转化计算，计算为等间隔的点 slpoint
        std::vector<TrajectoryPoint> lat_path;
        latpointcal.set_lat_coef(latpath);
        // latpointcal.set_lat_coef(testlatpath);

        double evaluation_horizon = latpath.smax;
        double FLAGS_trajectory_space_resolution = 0.5; // 间隔设置为0.5m
        for (double s = latpath.smin; s < evaluation_horizon; s += FLAGS_trajectory_space_resolution)
        {
            array<double, 3> s_condition;
            array<double, 3> d_condition;
            d_condition[0] = latpointcal.LATEvaluate(0, s - latpath.smin);
            d_condition[1] = latpointcal.LATEvaluate(1, s - latpath.smin);
            d_condition[2] = latpointcal.LATEvaluate(2, s - latpath.smin);
            s_condition[0] = s;
            s_condition[1] = 2; // 期望速度设置
            s_condition[2] = 0; // 期望加速度设置
            // 匹配点计算
            PathPoint matched_ref_point;
            pathmatcher_.MatchToPath(local_path_, matched_ref_point, s);
            cout << " s=" << s << " l=" << d_condition[0] << " x=" << matched_ref_point.x << " y=" << matched_ref_point.y << " s= " << matched_ref_point.s << endl;
            double x = 0.0;
            double y = 0.0;
            double theta = 0.0;
            double kappa = 0.0;
            double v = 0.0;
            double a = 0.0;

            const double rs = matched_ref_point.s;
            const double rx = matched_ref_point.x;
            const double ry = matched_ref_point.y;
            const double rtheta = matched_ref_point.theta;
            const double rkappa = matched_ref_point.kappa;
            const double rdkappa = matched_ref_point.dkappa;
            cartesianfrenetconverter.frenet_to_cartesian(rs, rx, ry, rtheta, rkappa, rdkappa, s_condition, d_condition,
                                                         &x, &y, &theta, &kappa, &v, &a);
            TrajectoryPoint latpoint;
            latpoint.x = x;
            latpoint.y = y;
            latpoint.theta = theta;
            latpoint.kappa = kappa;
            latpoint.v = v;
            latpoint.a = a;
            latpoint.s = s;
            lat_path.emplace_back(latpoint);
            std::cout << "x " << latpoint.x << " y: " << latpoint.y << std::endl;
        }
        // 坐标转化
        {
            std::lock_guard<std::mutex> lock(m_trajectory_point_mutex_);
            latpath_gcs.swap(lat_path);
            std::cout << "latpath_gcs: " << latpath_gcs.size() << std::endl;
        }
    }
    return 0;
}

int Planner::set_vehicle_report(VehicleReportMsg &vr)
{
    std::lock_guard<std::mutex> lock(m_vehicle_report_mutex_);
    if(m_vehicle_report_deque_.size() > m_max_queue_depth_)
    {
        m_vehicle_report_deque_.pop_front();
        std::cout << "func " << __FUNCTION__ << " queue size larger than max depth " << m_max_queue_depth_ << std::endl;
    }
    m_vehicle_report_deque_.emplace_back(vr);
    std::cout << "func " << __FUNCTION__ << "msg got,queue size is " << m_vehicle_report_deque_.size() << std::endl;

	return 0;

}
int Planner::set_reference_line(std::vector<PathPoint> &ref)
{
    std::lock_guard<std::mutex> lock(m_referenceline_mutex_);
    if(m_referenceline_deque_.size() > m_max_queue_depth_)
    {
        m_referenceline_deque_.pop_front();
        // std::cout << "func " << __FUNCTION__ << " queue size larger than max depth " << m_max_queue_depth_ << std::endl;
    }
    m_referenceline_deque_.push_back(ref);
    // std::cout << "func " << __FUNCTION__ << "msg got,queue size is " << m_referenceline_deque_.size() 
    // << " ref size : " << ref.size()
    // << std::endl;

	return 0;
}

int Planner::set_location(PathPoint &location)
{
    std::lock_guard<std::mutex> lock(m_location_mutex_);
    if(m_location_deque_.size() > m_max_queue_depth_)
    {
        m_location_deque_.pop_front();
        std::cout << "func " << __FUNCTION__ << " queue size larger than max depth " << m_max_queue_depth_ << std::endl;
    }
    m_location_deque_.emplace_back(location);
    std::cout << "func " << __FUNCTION__ << "msg got,queue size is " << m_location_deque_.size() << std::endl;

	return 0;
}

int Planner::set_object(Obstacle &obj)
{
    std::lock_guard<std::mutex> lock(m_obstacle_mutex_);
    if(m_obstacle_deque_.size() > m_max_queue_depth_)
    {
        m_obstacle_deque_.pop_front();
        std::cout << "func " << __FUNCTION__ << " queue size larger than max depth " << m_max_queue_depth_ << std::endl;
    }
    m_obstacle_deque_.emplace_back(obj);
    std::cout << "func " << __FUNCTION__ << "msg got,queue size is " << m_obstacle_deque_.size() << std::endl;
	return 0;
}

int Planner::set_state_machine(StateMachine &s)
{
    std::lock_guard<std::mutex> lock(m_state_mutex_);
    if(m_state_deque_.size() > m_max_queue_depth_)
    {
        m_state_deque_.pop_front();
        std::cout << "func " << __FUNCTION__ << " queue size larger than max depth " << m_max_queue_depth_ << std::endl;
    }
    m_state_deque_.emplace_back(s);
    std::cout << "func " << __FUNCTION__ << "msg got,queue size is " << m_state_deque_.size() << std::endl;

	return 0;
}
std::vector<TrajectoryPoint> Planner::get_latpath()
{
    std::vector<TrajectoryPoint> tmp;
    {
        std::lock_guard<std::mutex> lock(m_trajectory_point_mutex_);
        tmp.swap(latpath_gcs);
    }
    return tmp;
}

Planner::~Planner()
{
}